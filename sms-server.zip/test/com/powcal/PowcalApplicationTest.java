package com.powcal;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ZipUtil;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.result.R;
import com.powcal.service.DataPlusService;
import com.powcal.service.domain.LogDataDto;
import com.powcal.utils.CollUtils;
import com.powcal.utils.JavaTimeUtils;
import com.powcal.utils.StrUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@EnableAsync
@EnableScheduling
@EnableCaching
@Slf4j
@SpringBootTest
public class PowcalApplicationTest {

    @Test
    public void test(){
        PowcalSitepowEntity powcalSitepowEntity = new PowcalSitepowEntity();
        powcalSitepowEntity.setActivePowerOne("1");
        powcalSitepowEntity.setActivePower("2");
        powcalSitepowEntity.setLimitPower("3");
        powcalSitepowEntity.setReactivePower("4");
        powcalSitepowEntity.setReactivePowerOne("5");
        powcalSitepowEntity.setRelimitPower("6");
        powcalSitepowEntity.setAvcDy("7");
        powcalSitepowEntity.setQckjrl("8");
        powcalSitepowEntity.setHasld(1);
        powcalSitepowEntity.setSiteId("GDYJXYA");
        Double activePowerOne = powcalSitepowEntity.getActivePowerOnetoDouble();
        log.warn(activePowerOne+"");
    }

    @Autowired
    private DataPlusService dataPlusService;
    @Test
    public void test1() throws Exception {
        LocalDateTime startTime=LocalDateTime.parse("2023-10-02 00:00:00");
        LocalDateTime endTime=LocalDateTime.parse("2023-10-03 00:00:00");
        dataPlusService.dataPlus_GD(startTime,endTime);
    }


    public static void main(String[] args) throws IOException {
        LocalDateTime startTime = LocalDate.parse("2023-09-30").atTime(0,0,0);
        LocalDateTime endTime = LocalDate.parse("2023-09-30").atTime(23,59,59);
        String path = "/home/powcal/logs/sms";
        String fileName = "data" + JavaTimeUtils.format(startTime.toLocalDate(), "yyyyMMdd") + ".log";
        String fileType = ".zip";
        String filePath = path + "/data/" + fileName + fileType;
        File unzip = null;

        //原始数据
        List<String> lineList = null;
        Stream<String> inputStream = null;
        try {
            inputStream = Files.lines(Paths.get(path + "/data/" + fileName), StandardCharsets.UTF_8);
//            FileUtil.del(path + "/data/" + fileName);
        } catch (Exception E) {
            if (unzip != null) {
                unzip.delete();
            }
            log.error(E.getMessage(), E);
            inputStream = Files.lines(Paths.get(path + "/data/" + fileName), StandardCharsets.UTF_8);
            //lineList = FileUtils.readLines();
        }
        List<J60870MonitorRecordEntity> PowcalSitepowList = new ArrayList<>();//场站（升压站）功率监测
        List<J60870MonitorRecordEntity> PowcalFjpowList = new ArrayList<>();//风机功率监测
        List<J60870MonitorRecordEntity> PowcalCftwindList = new ArrayList<>();//测风塔风速
        List<J60870MonitorRecordEntity> PowcalSitetherpowList = new ArrayList<>();//场站(测风塔or激光雷达)温度


        if (inputStream != null) {
            List<LogDataDto> list = inputStream.parallel().filter(line -> {
                line=line.replace("E-", "");
                line = line.replace("T", " ");
                List<String> colList = StrUtils.split(line, ",");
                if (CollUtils.size(colList) > 3) {
//                    String replace = colList.get(0).replace("T", " ");
                    String replace = colList.get(0).toString();
                    LocalDateTime recordTime = JavaTimeUtils.parse(replace, "yyyy-MM-dd HH:mm:ss").withSecond(0);
                    return recordTime.isAfter(startTime.plusMinutes(-1)) && recordTime.isBefore(endTime.plusMinutes(1));
                }
                return false;
            }).map(line -> {
                List<String> colList = StrUtils.split(line, ",");
                LogDataDto logDataDto = new LogDataDto();

                String replace = colList.get(0).replace("T", " ");
                LocalDateTime recordTime = JavaTimeUtils.parse(replace, "yyyy-MM-dd HH:mm:ss").withSecond(0);
                logDataDto.setTime(recordTime);
                logDataDto.setType(colList.get(1));
                logDataDto.setPoint(colList.get(2));
                logDataDto.setValue(colList.get(3));
                return logDataDto;
            }).toList();
            list.forEach(logDataDto -> {
                LocalDateTime recordTime = logDataDto.getTime();
                J60870MonitorRecordEntity doc = new J60870MonitorRecordEntity();
                String point = logDataDto.getPoint();
                //补充数据
//                Map<String, String> stringStringMap = monitoringPoint11.get(point);
//                doc.setCreateTime(recordTime);
//                doc.setMonitoringPoint(point);
//                doc.setMonitoringValue(logDataDto.getValue());
//                if (stringStringMap != null) {
//                    String SITE = stringStringMap.get("SITES");
//                    String DEVICE_TYPE = stringStringMap.get("DEVICE_TYPE");
//                    String POINT_TYPE = stringStringMap.get("POINT_TYPE");
//                    String FAN_NUMBER = stringStringMap.get("FAN_NUMBER");
//                    String FAN_CODE = stringStringMap.get("FAN_CODE");
//                    String FJ_HEIGHT = stringStringMap.get("FJ_HEIGHT");
//                    String IS_MODEL = stringStringMap.get("IS_MODEL");
//                    String POW_VALUE = stringStringMap.get("POW_VALUE");
//                    doc.setPowValue(POW_VALUE);
//                    doc.setSiteid(SITE);
//                    doc.setDeviceType(DEVICE_TYPE);
//                    doc.setPointType(POINT_TYPE);
//                    doc.setFan_code(FAN_CODE);//012080
//                    doc.setFan_number(FAN_NUMBER);//#12
//                    doc.setFJ_HEIGHT(FJ_HEIGHT);
//                    doc.setIs_model(IS_MODEL);
//                    if(doc!=null){
//                        if (DEVICE_TYPE.equals("SYZ")) {//场站功率监测数据表【POWCAL_SITEPOW】
//                            PowcalSitepowList.add(doc);
//                        } else if (DEVICE_TYPE.equals("FJ")) {//风机功率监测数据表
//                            PowcalFjpowList.add(doc);
//                        } else if (POINT_TYPE.equals("SPEED") || POINT_TYPE.equals("DIRECTION") || POINT_TYPE.equals("SPEED_H") || POINT_TYPE.equals("DIRECTION_H") || POINT_TYPE.equals("SPEED_AVG") || POINT_TYPE.equals("DIRECTION_AVG") || POINT_TYPE.equals("SPEED_SDH")) {//测风塔不同高度风速风向
//                            PowcalCftwindList.add(doc);
//                        } else if (POINT_TYPE.equals("PRESSURE") || POINT_TYPE.equals("HUMIDITY") || POINT_TYPE.equals("TEMPERATURE")) {//场站(测风塔or激光雷达)温度
//                            PowcalSitetherpowList.add(doc);
//                        }
//                    }
//
//                }

            });
        }
    }
}
