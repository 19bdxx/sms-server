package com.powcal.result;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseResultCode {
    public static final String EMPTY = "";
    public static final String MSG_SUCCESS = "success";
    public static final String MSG_ERROR = "error";
    public static final String RESULT_SUCCESS = "success";
    public static final String RESULT_CODE = "code";
    public static final String RESULT_MSG = "msg";
    public static final String RESULT_DATA = "data";
    public static final String RESULT_LIST_ROWS = "listRows";
    public static final String RESULT_PAGE_ROWS = "pageRows";
    public static final String RESULT_PAGE_NUM = "pageNum";
    public static final String RESULT_PAGE_SIZE = "pageSize";
    public static final String RESULT_TOTAL = "total";
    public static final String TOKEN_NAME = "X-Access-Token";
    public static final String AUTHORIZATION = "Authorization";
    public static final Map<String, Object> EMPTY_DATA = new HashMap<>();
    public static final List<String> EMPTY_LIST = new ArrayList<>();

    public static final int SUCCESS = 200;
    public static final int HTTP_OK = 200;
    public static final int BAD_REQUEST = 400;
    public static final int UNAUTHORIZED = 401;
    public static final int FORBIDDEN = 403;
    public static final int NOT_FOUND = 404;
    public static final int INTERNAL_SERVER_ERROR = 500;
    public static final int SERVICE_UNAVAILABLE = 503;
    public static final int BROKEN_PIPE = 510;

}

