package com.powcal.result;


import com.powcal.common.excption.code.SystemCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class R<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    private int code;
    private String msg;
    private T data;

    public static <T> R<T> success() {
        return new R<>(BaseResultCode.SUCCESS, BaseResultCode.MSG_SUCCESS, null);
    }

    public static <T> R<T> success(T data) {
        return new R<>(BaseResultCode.SUCCESS, BaseResultCode.MSG_SUCCESS, data);
    }

    public static <T> R<T> fail(int code, String message) {
        return new R<>(code, message, null);
    }


    public static R fail(SystemCode systemCode) {
        return new R<>(systemCode.getFullCode(), systemCode.getMessage(), null);
    }
}
