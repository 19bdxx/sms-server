package com.powcal.error;


import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;

import java.io.Serial;

public class RoseException extends RuntimeException {
    /**
     *
     */
    @Serial
    private static final long serialVersionUID = 1L;
    protected int code;
    protected HttpStatus httpStatus = HttpStatus.OK;

    protected LogLevel logLevel;
    protected boolean logThrow = false;

    public RoseException(int code, String message, LogLevel logLevel) {
        super(message);
        this.code = code;
        this.logLevel = logLevel;
    }

    public RoseException(int code, String message, LogLevel logLevel, Throwable t) {
        super(message, t);
        this.code = code;
        this.logLevel = logLevel;
        logThrow = true;
    }

    public RoseException(HttpStatus httpStatus, int code, String message, LogLevel logLevel) {
        super(message);
        this.httpStatus = httpStatus;
        this.code = code;
        this.logLevel = logLevel;
    }

    public RoseException(HttpStatus httpStatus, int code, String message, LogLevel logLevel, Throwable t) {
        super(message, t);
        this.httpStatus = httpStatus;
        this.code = code;
        this.logLevel = logLevel;
        logThrow = true;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public LogLevel getLogLevel() {
        return logLevel;
    }

    public void setLogLevel(LogLevel logLevel) {
        this.logLevel = logLevel;
    }

    public boolean isLogThrow() {
        return logThrow;
    }

    public void setLogThrow(boolean logThrow) {
        this.logThrow = logThrow;
    }
}
