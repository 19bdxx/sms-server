package com.powcal.utils;

import cn.hutool.core.comparator.CompareUtil;
import cn.hutool.core.util.ArrayUtil;

import java.util.Objects;

public class CompareUtils extends CompareUtil {

    public static <T extends Comparable<T>> boolean equals(T i, T arg) {
        if (i == null && arg == null) {
            return true;
        } else if (i != null && arg != null) {
            return i.compareTo(arg) == 0;
        }
        return false;
    }

    public static boolean equals(Object o1, Object o2) {
        return Objects.equals(o1, o2);
    }

    @SafeVarargs
    public static <T extends Comparable<T>> boolean equalsAny(T i, T... args) {
        if (i != null && ArrayUtil.isNotEmpty(args)) {
            for (T arg : args) {
                if (equals(i, arg)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static <T extends Comparable<? super T>> boolean isGreaterThan(T c1, T c2) {
        return compare(c1, c2, false) > 0;
    }

    public static <T extends Comparable<? super T>> boolean isLessThan(T c1, T c2) {
        return compare(c1, c2, false) < 0;
    }


    public static <T extends Number> boolean isGreaterThanZero(T arg) {
        return arg != null && arg.doubleValue() > 0;
    }

    @SafeVarargs
    public static <T extends Number> boolean isAllGreaterThanZero(T... args) {
        if (ArrayUtil.isNotEmpty(args)) {
            for (T arg : args) {
                if (!isGreaterThanZero(arg)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    @SafeVarargs
    public static <T extends Number> boolean isAnyGreaterThanZero(T... args) {
        if (ArrayUtil.isNotEmpty(args)) {
            for (T arg : args) {
                if (isGreaterThanZero(arg)) {
                    return true;
                }
            }
        }
        return false;
    }

}
