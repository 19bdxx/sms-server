package com.powcal.utils;


import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.LocalDateTimeUtil;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class JavaTimeUtils extends LocalDateTimeUtil {

    public static String formatNormal() {
        return formatNormal(now());
    }

    public static String formatNow(String format) {
        return format(LocalDateTime.now(), format);
    }

    public static String formatNow(DateTimeFormatter format) {
        return format(LocalDateTime.now(), format);
    }

    public static List<String> getQuarterHours(LocalDateTime start, LocalDateTime end,long interval,ChronoUnit chronoUnit) {
        List<String> result = new ArrayList<>();
        LocalDateTime current = start;
        while (current.isBefore(end) || current.isEqual(end)) {
            result.add(current.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            current = current.plus(interval,chronoUnit); // 增加15分钟，即一刻钟
        }
        return result;
    }

    public static LocalDate ofDate(Object date) {
        if (date != null) {
            if (date instanceof LocalDate localDate) {
                return localDate;
            } else if (date instanceof LocalDateTime localDateTime) {
                return localDateTime.toLocalDate();
            } else if (date instanceof TemporalAccessor temporal) {
                return ofDate(temporal);
            } else if (date instanceof java.sql.Date sqlDate) {
                return sqlDate.toLocalDate();
            } else {
                LocalDateTime dateTime = of(date);
                if (dateTime != null) {
                    return dateTime.toLocalDate();
                }
            }
        }
        return null;
    }

    public static LocalDateTime of(Object dateTime) {
        if (dateTime != null) {
            if (dateTime instanceof TemporalAccessor temporal) {
                return of(temporal);
            } else if (dateTime instanceof java.sql.Date sqlDate) {
                return of(new Date(sqlDate.getTime()));
            } else if (dateTime instanceof Date date) {
                return of(date);
            } else {
                return of(dateTime.toString());
            }
        }
        return null;
    }

    public static LocalDateTime of(String dateTime) {
        if (StrUtils.isNotBlank(dateTime)) {
            if (NumberUtils.isNumber(dateTime)) {
                if (StrUtils.length(dateTime) == DatePattern.PURE_DATETIME_PATTERN.length()) {
                    return parse(dateTime, DatePattern.PURE_DATETIME_FORMATTER);
                } else if (StrUtils.length(dateTime) == DatePattern.PURE_DATE_PATTERN.length()) {
                    LocalDate localDate = parseDate(dateTime, DatePattern.PURE_DATE_FORMATTER);
                    return localDate.atStartOfDay();
                }
                return of(Long.parseLong(dateTime));
            }
            try {
                DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                        .appendPattern("yyyy-MM-dd[['T'][' '][HH][:mm][:ss][.SSS]]")
                        .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
                        .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
                        .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0)
                        .parseDefaulting(ChronoField.MILLI_OF_SECOND, 0)
                        .toFormatter();
                return LocalDateTime.parse(dateTime, formatter);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    public static List<LocalDateTime> getDatetimeList(LocalDateTime startTime, LocalDateTime endTime, long interval, TimeUnit timeUnit) {
        List<LocalDateTime> periodList = new ArrayList<>();
        LocalDateTime cursor = startTime;
//        while (cursor.isBefore(endTime)) {
        while (!cursor.isAfter(endTime)){
            periodList.add(cursor);
            long mills = DateUtils.getMilliSeconds(interval, timeUnit);
            cursor = cursor.plus(mills, ChronoUnit.MILLIS);
        }
        return periodList;
    }

    public static List<String> getDatetimeStrList(LocalDateTime startTime, LocalDateTime endTime, long interval, TimeUnit timeUnit) {
        List<String> strList = new ArrayList<>();
        for (LocalDateTime datetime : getDatetimeList(startTime, endTime, interval, timeUnit)) {
            strList.add(JavaTimeUtils.formatNormal(datetime));
        }
        return strList;
    }

    public static List<String> getDatetimeStrList_ISO(LocalDateTime startTime, LocalDateTime endTime, long interval, TimeUnit timeUnit) {
        List<String> strList = new ArrayList<>();
        for (LocalDateTime datetime : getDatetimeList(startTime, endTime, interval, timeUnit)) {
            strList.add(datetime.toString());
        }
        return strList;
    }


}
