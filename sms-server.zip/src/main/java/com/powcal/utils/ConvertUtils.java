package com.powcal.utils;

import cn.hutool.core.convert.Convert;

import java.util.*;

public class ConvertUtils extends Convert {

    public static List<Integer> toIntList(List<?> list) {
        return toIntList(list, true);
    }

    public static List<Integer> toIntList(List<?> list, boolean ignoreNull) {
        if (list != null) {
            List<Integer> intList = new ArrayList<>();
            for (Object one : list) {
                Integer val = toInt(one);
                if (val != null || !ignoreNull) {
                    intList.add(val);
                }
            }
            return intList;
        }
        return null;
    }

    public static List<String> toStrList(Collection<?> list) {
        return toStrList(list, false);
    }

    public static List<String> toStrList(Collection<?> list, boolean ignoreNull) {
        if (list != null) {
            List<String> strList = new ArrayList<>();
            for (Object one : list) {
                if (one != null || !ignoreNull) {
                    strList.add(toStr(one));
                }
            }
            return strList;
        }
        return null;
    }

    public static <T> Map<String, T> toStrKeyMap(Map<?, T> map) {
        if (map != null) {
            Map<String, T> strMap = new LinkedHashMap<>();
            if (map.size() > 0) {
                for (Map.Entry<?, T> entry : map.entrySet()) {
                    strMap.put(ConvertUtils.toStr(entry.getKey()), entry.getValue());
                }
            }
            return strMap;
        }
        return null;
    }

    public static Map<String, String> toStrKeyStrValueMap(Map<?, ?> map) {
        if (map != null) {
            Map<String, String> strMap = new LinkedHashMap<>();
            if (map.size() > 0) {
                for (Map.Entry<?, ?> entry : map.entrySet()) {
                    strMap.put(ConvertUtils.toStr(entry.getKey()), ConvertUtils.toStr(entry.getValue()));
                }
            }
            return strMap;
        }
        return null;
    }

}