package com.powcal.utils;


import cn.hutool.core.util.StrUtil;

import java.math.BigInteger;
import java.util.Stack;

public class StrUtils extends StrUtil {

    public static String lowerCase(final String str) {
        if (str == null) {
            return null;
        }
        return str.toLowerCase();
    }

    public static String upperCase(final String str) {
        if (str == null) {
            return null;
        }
        return str.toUpperCase();
    }

    public static String toStringOrNull(Object o) {
        if (o != null) {
            return o.toString();
        }
        return null;
    }

    public static String toStringAndTrimToNull(Object o) {
        if (o != null) {
            return trimToNull(o.toString());
        }
        return null;
    }

    public static String toStringAndTrimToEmpty(Object o) {
        if (o != null) {
            return trimToEmpty(o.toString());
        }
        return EMPTY;
    }

    public static boolean isNumeric(final CharSequence cs) {
        if (isEmpty(cs)) {
            return false;
        }
        final int sz = cs.length();
        for (int i = 0; i < sz; i++) {
            if (!Character.isDigit(cs.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static String left(final String str, final int len) {
        return subPre(str, len);
    }

    public static String right(final String str, final int len) {
        return subSufByLength(str, len);
    }

    public static String decimalToAny(String digits, String number) {
        BigInteger num = new BigInteger(number);
        StringBuilder str = new StringBuilder();
        BigInteger base = new BigInteger(String.valueOf(digits.trim().length()));
        Stack<Character> s = new Stack<>();
        while (num.compareTo(BigInteger.ZERO) > 0) {
            s.push(digits.charAt(num.remainder(base).intValue()));
            num = num.divide(base);
        }
        while (!s.isEmpty()) {
            str.append(s.pop());
        }
        return str.toString();
    }

    public static void main(String[] args) {
        System.out.println(decimalToAny("0123456789abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ", "865373042618517"));

        System.out.println(Long.toHexString(865373042618517L));
    }


}
