package com.powcal.utils;

import cn.hutool.core.util.NumberUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class NumberUtils extends NumberUtil {

    private final DecimalFormat df = new DecimalFormat("##0.00");

    public static boolean isOdd(Integer num) {
        return num != null && num % 2 == 1;
    }

    public static boolean isEven(Integer num) {
        return num != null && num % 2 == 0;
    }


    /**
     * 将 double 类型的值保留两位小数，并返回 double 类型的结果。
     *
     * @param value 需要处理的 double 值
     * @return 保留两位小数的 double 值
     */
    public static Double roundToTwoDecimals(Double value) {
        if (value == null) {
            return null;
        }
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    /**
     * 将 double 类型的值保留两位小数，并返回 double 类型的结果。
     *
     * @param value 需要处理的 double 值
     * @return 保留两位小数的 double 值
     */
    public static Double roundToTwoDecimals(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(2, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    /**
     * string转double
     */
    public static Double parseToDouble(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        if (value.equalsIgnoreCase("null")) {
            return null;
        }
        BigDecimal bd = new BigDecimal(value);
        return bd.doubleValue();
    }


}
