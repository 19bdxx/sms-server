package com.powcal.utils;


import cn.hutool.core.collection.CollUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CollUtils extends CollUtil {

    public static boolean isNoneEmpty(Collection<?>... collections) {
        if (collections == null || collections.length == 0) {
            return false;
        } else {
            for (Collection<?> collection : collections) {
                if (isEmpty(collection)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 移除指定
     */
    public static <E> List<E> removeAll(final Collection<E> collection, final Collection<?> remove) {
        final List<E> list = new ArrayList<>();
        for (final E obj : collection) {
            if (!remove.contains(obj)) {
                list.add(obj);
            }
        }
        return list;
    }

    /**
     * 平均分配
     */
    public static <E> List<List<E>> allot(final Collection<E> collection, final int dividend) {
        int total = CollUtils.size(collection);
        if (total > 0) {
            List<List<E>> list = new ArrayList<>();
            int minimum = total / dividend;
            int remainder = total % dividend;
            List<E> subList = new ArrayList<>();
            int iSub = 0;
            int subMax = remainder > 0 ? minimum + 1 : minimum;
            for (E e : collection) {
                subList.add(e);
                if (subList.size() == subMax) {
                    list.add(subList);
                    subList = new ArrayList<>(minimum + 1);
                    iSub++;
                    subMax = iSub < remainder ? minimum + 1 : minimum;
                }
            }
            return list;
        }
        return new ArrayList<>();
    }

    public static boolean isEmpty(String str) {
        return str == null || str.isEmpty();
    }
}


