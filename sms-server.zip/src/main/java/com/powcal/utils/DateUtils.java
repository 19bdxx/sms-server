package com.powcal.utils;


import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import com.powcal.result.DateRange;

import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class DateUtils extends DateUtil {
    protected static final ZoneId DEFAULT_ZONE = ZoneId.systemDefault();

    public static final int SECOND_MILLISECONDS = 1000;
    public static final int MINUTE_MILLISECONDS = 60 * 1000;
    public static final int HOUR_MILLISECONDS = 60 * 60 * 1000;
    public static final int DAY_MILLISECONDS = 24 * 60 * 60 * 1000;

    public static String formatNormal() {
        return formatNormal(new Date());
    }


    public static String formatNormal(Date date) {
        return getFormat(DatePattern.NORM_DATETIME_PATTERN).format(date);
    }

    public static SimpleDateFormat getFormat(String pattern) {
        return new SimpleDateFormat(pattern);
    }

    public static String timestampOfJavaScript() {
        return timestampOfJavaScript(new Date());
    }

    public static String timestampOfJavaScript(Date date) {
        return String.valueOf(date.getTime());
    }

    public static String timestampOfUnix() {
        return timestampOfUnix(new Date());
    }

    public static String timestampOfUnix(Date date) {
        return String.valueOf(date.getTime() / SECOND_MILLISECONDS);
    }

    public static Date of(LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        Instant instant = localDateTime.atZone(DEFAULT_ZONE).toInstant();
        return Date.from(instant);
    }

    public static Date of(LocalDate localDate) {
        if (localDate == null) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(DEFAULT_ZONE);
        return Date.from(zonedDateTime.toInstant());
    }

    public static long getMilliSeconds(long time, TimeUnit unit) {
        switch (unit) {
            case MILLISECONDS -> {
                return time;
            }
            case SECONDS -> {
                return time * SECOND_MILLISECONDS;
            }
            case MINUTES -> {
                return time * MINUTE_MILLISECONDS;
            }
            case HOURS -> {
                return time * HOUR_MILLISECONDS;
            }
            case DAYS -> {
                return time * DAY_MILLISECONDS;
            }
            default -> {
            }
        }
        return 0L;
    }


    public static String secondToChineseTime(Integer seconds) {
        if (CompareUtils.isGreaterThanZero(seconds)) {
            int hours = (seconds % 86400) / 3600;
            int minutes = (seconds % 3600) / 60;
            int ss = seconds % 60;
            StringBuilder stringBuilder = new StringBuilder(32);
            if (hours > 0) {
                stringBuilder.append(hours);
                stringBuilder.append("时");
            }
            if (minutes > 0) {
                stringBuilder.append(minutes);
                stringBuilder.append("分");
            }
            if (ss > 0) {
                stringBuilder.append(ss);
                stringBuilder.append("秒");
            }
            return stringBuilder.toString();
        }
        return "0";
    }

    /**
     * 按月分割
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @return 分割后的时间段集合
     */
    public static List<DateRange> splitDateRangeByMonth(LocalDateTime startTime, LocalDateTime endTime) {
        long seconds = startTime.until(endTime, ChronoUnit.SECONDS);
        if (seconds <= 0) {
            return new ArrayList<>();
        }
        //轮数
        long turnNum = 0;
        //分割的时间段集合，使用累加算法
        List<DateRange> dateList = new ArrayList<>();
        DateRange range = new DateRange();
        range.setBegin(startTime);
        while (true) {
            turnNum++;
            startTime = startTime.plusMonths(1);
            //大于截止日期时，不再累加
            if (startTime.isAfter(endTime)) {
                range.setEnd(endTime);
                range.setTurnNum(turnNum);
                dateList.add(range);
                break;
            }
            //将时间调整为当前月的第一天的 0时 0分 0秒
            startTime = LocalDateTime.of(LocalDate.from(startTime.with(TemporalAdjusters.firstDayOfMonth())), LocalTime.MIN);
            LocalDateTime tmpBegin = startTime;
            //计算出上一天的最后一秒
            LocalDateTime endDate = tmpBegin.minusSeconds(1);
            range.setEnd(endDate);
            range.setTurnNum(turnNum);
            dateList.add(range);
            //创建新的时间段
            range = new DateRange();
            range.setBegin(tmpBegin);
        }
        return dateList;
    }

}
