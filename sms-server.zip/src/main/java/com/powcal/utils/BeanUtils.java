package com.powcal.utils;


import cn.hutool.core.bean.BeanUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class BeanUtils extends BeanUtil {
    private static final Logger log = LoggerFactory.getLogger(BeanUtils.class);

    public static String getFieldStrValue(Object bean, String name) {
        Object val = getFieldValue(bean, name);
        if (val != null) {
            return val.toString();
        }
        return null;
    }

    public static <T, V> V getProperty(T t, Function<T, V> valueFun) {
        return getProperty(t, valueFun, null);
    }

    public static <T, V> V getProperty(T t, Function<T, V> valueFun, V defaultValue) {
        if (t != null) {
            V v = valueFun.apply(t);
            if (v != null) {
                return v;
            }
        }
        return defaultValue;
    }

    public static <T, V> List<V> getPropertyOfList(List<T> list, Function<T, V> valueFun) {
        return getPropertyOfList(list, valueFun, true);
    }

    public static <T, V> List<V> getPropertyOfList(List<T> list, Function<T, V> valueFun, boolean ignoreNull) {
        if (list != null) {
            List<V> valList = new ArrayList<>();
            for (T t : list) {
                V val = valueFun.apply(t);
                if (val != null || ignoreNull) {
                    valList.add(val);
                }
            }
            return valList;
        }
        return null;
    }

}
