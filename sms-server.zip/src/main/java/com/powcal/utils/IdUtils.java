package com.powcal.utils;

import cn.hutool.core.util.IdUtil;

import java.io.Serializable;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

public class IdUtils extends IdUtil {

    public static boolean isValidId(Serializable id) {
        if (id != null) {
            if (id instanceof Integer intVal) {
                return intVal > 0;
            } else if (id instanceof Long longVal) {
                return longVal > 0;
            } else if (id instanceof String strVal) {
                if (StrUtils.isNumeric(strVal)) {
                    return ConvertUtils.toLong(strVal) > 0;
                }
                return !strVal.isEmpty() && !strVal.isBlank();
            }
        }
        return false;
    }

    public static <T extends Serializable> Set<T> getValidIds(Collection<T> idColl) {
        Set<T> ids = new LinkedHashSet<>();
        if (CollUtils.isNotEmpty(idColl)) {
            for (T id : idColl) {
                if (isValidId(id)) {
                    ids.add(id);
                }
            }
        }
        return ids;
    }
}
