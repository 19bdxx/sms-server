package com.powcal.common.state;

import com.powcal.entity.base.AbstractEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description: 状态
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public abstract class AbstractState implements State {
    private AbstractEntity abstractEntity;

}
