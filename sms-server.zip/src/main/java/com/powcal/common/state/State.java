package com.powcal.common.state;

import com.powcal.entity.base.AbstractEntity;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description: 状态
 */
public interface State {

    Double hendler(Double value);

}
