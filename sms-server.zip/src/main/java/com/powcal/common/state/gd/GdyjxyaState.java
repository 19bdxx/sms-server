package com.powcal.common.state.gd;

import com.powcal.common.state.State;
import com.powcal.entity.base.AbstractEntity;
import com.powcal.utils.ConvertUtils;
import lombok.NoArgsConstructor;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description:
 */
@NoArgsConstructor
public class GdyjxyaState implements State {

    @Override
    public Double hendler(Double value ) {
        return value > 0.0 ? 0.0 : Math.abs(value);
    }


}
