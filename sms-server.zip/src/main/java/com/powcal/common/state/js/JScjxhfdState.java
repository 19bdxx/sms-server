package com.powcal.common.state.js;

import com.powcal.common.state.State;
import lombok.NoArgsConstructor;

/**
 * @Author 喻俊杰
 * @Date:2024/11/19
 * @Description:
 */
@NoArgsConstructor
public class JScjxhfdState implements State {
    @Override
    public Double hendler(Double value) {
        return value >0.0 ? 0.0 :Math.abs(value) ;
    }
}
