package com.powcal.common.state;

import com.powcal.entity.base.AbstractEntity;
import lombok.NoArgsConstructor;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description:
 */
@NoArgsConstructor
public class UnknownState implements State {



    @Override
    public Double hendler(Double value) {
        return value;
    }
}
