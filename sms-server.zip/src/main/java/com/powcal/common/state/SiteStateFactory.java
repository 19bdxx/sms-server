package com.powcal.common.state;

import com.powcal.common.eunm.SiteEnum;
import com.powcal.entity.base.AbstractEntity;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description:
 */
public class SiteStateFactory {
    private void SiteStateFactory (){

    };
    public static State getState( String site){
        try{
           return SiteEnum.getState(site);
        }catch (Exception e){
            return new UnknownState();
        }
    }
}
