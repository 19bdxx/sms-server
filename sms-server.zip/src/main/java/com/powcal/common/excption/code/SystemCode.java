package com.powcal.common.excption.code;

import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * 通用业务异常code
 */
@Getter
@AllArgsConstructor
public enum SystemCode implements IErrorCode {


    /**
     * 操作成功
     */
    SUCCESS(200, "success"),

    /**
     * 业务异常
     */
    FAILURE(500, "failure"),

    /**
     * 参数错误
     */
    PARAMETER_ERROR(422, "parameter error"),

    ;


    /**
     * code编码
     */
    final int code;
    /**
     * 描述信息
     */
    final String message;

    @Override
    public int getModuleCode() {
        return 100;
    }
}
