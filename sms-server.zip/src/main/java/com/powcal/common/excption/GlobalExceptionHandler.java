package com.powcal.common.excption;


import com.powcal.common.excption.code.SystemCode;
import com.powcal.result.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;
import java.util.Set;


@RestControllerAdvice(basePackages = {"com.dataProcessing.control.report"})
@Slf4j
public class GlobalExceptionHandler {


    /**
     * 处理业务异常的全局异常处理器。
     * 当发生{@link BusinessException}时，此方法将被调用，用于统一处理业务异常，并返回相应的错误信息。
     *
     * @param e 发生的业务异常对象，包含错误代码和错误信息。
     * @return 返回一个包含错误代码和错误信息的响应对象{@link R}。
     */
    @ExceptionHandler(value = BusinessException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    private R businessException(BusinessException e) {
        log.error("GlobalExceptionHandler catch BusinessException", e); // 记录业务异常日志
        return R.fail(e.getCode(), e.getMessage()); // 返回包含错误信息的响应对象
    }



    /**
     * 处理缺少ServletRequest参数的异常。
     * 当客户端请求中缺少必要的参数时，服务器会抛出此异常。
     *
     * @param e 抛出的异常对象，指示缺少哪个请求参数。
     * @return 返回一个表示操作失败的结果对象，其中包含了错误代码和错误信息。
     */
    @ExceptionHandler(value = MissingServletRequestParameterException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private R missingServletRequestParameterException(Exception e) {
        log.error("GlobalExceptionHandler catch MissingServletRequestParameterException", e); // 记录业务异常日志
        return R.fail(SystemCode.FAILURE);
    }


    /**
     * 处理方法参数不合法的异常。
     * 当客户端提交的请求参数不满足验证条件时，会抛出MethodArgumentNotValidException异常。
     * 该异常处理器会将异常信息转换为相应的响应体返回给客户端。
     *
     * @param e MethodArgumentNotValidException 异常对象，包含验证失败的详细信息。
     * @return R 返回一个结果对象，其中包含错误代码和错误信息。
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private R methodArgumentNotValidException(MethodArgumentNotValidException e) {
        log.error("GlobalExceptionHandler catch MethodArgumentNotValidException", e); // 记录业务异常日志
        // 校验失败后的国际化处理
        BindingResult bindingResult = e.getBindingResult();
        if (bindingResult.hasErrors()) {
            // 处理字段验证错误
            List<FieldError> fieldErrors = bindingResult.getFieldErrors();
            List<String> errorList = fieldErrors.stream().map(DefaultMessageSourceResolvable::getDefaultMessage).toList();
            // 将字段错误信息合并后返回
            return R.fail(SystemCode.PARAMETER_ERROR.getCode(), String.join(",", errorList));
        }
        // 无字段错误时，返回内部服务器错误
        return R.fail(SystemCode.FAILURE);
    }


    /**
     * 处理IllegalArgumentException异常的全局异常处理器。
     * 当控制器或其方法抛出IllegalArgumentException异常时，此处理器将捕获该异常，并返回一个相应的错误响应。
     *
     * @param e 抛出的IllegalArgumentException异常实例。
     * @return 返回一个表示操作失败的响应对象R，其中包含了系统的错误代码。
     */
    @ExceptionHandler(value = IllegalArgumentException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private R illegalArgumentException(Exception e) {
        log.error("GlobalExceptionHandler catch IllegalArgumentException", e); // 记录业务异常日志
        return R.fail(SystemCode.FAILURE);
    }


    /**
     * 处理HTTP消息不可读异常。
     * 当客户端提交的请求体无法被解析时，会抛出此异常。
     *
     * @param e 异常对象，包含具体的错误信息。
     * @return 返回一个包含错误代码和消息的响应体对象R。
     * 响应体中的错误代码表示请求处理失败，错误消息提示请求参数有误。
     */
    @ExceptionHandler(value = HttpMessageNotReadableException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    private R httpMessageNotReadableException(Exception e) {
        log.error("GlobalExceptionHandler catch HttpMessageNotReadableException", e); // 记录业务异常日志
        return R.fail(SystemCode.FAILURE.getCode(), "body resolution error");
    }



    /**
     * 全局异常处理方法。
     * 该方法用于捕获控制器层抛出的任意异常，并返回一个统一格式的错误响应体。
     *
     * @param e 异常对象，捕获到的任意异常都将传入此参数。
     * @return 返回一个表示操作失败的响应体R，其中包含了系统的错误码。
     */
    @ExceptionHandler(value =Exception.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    private R exception(Exception e) {
        log.error("GlobalExceptionHandler catch Exception", e); // 记录业务异常日志
        return R.fail(SystemCode.FAILURE);
    }
}
