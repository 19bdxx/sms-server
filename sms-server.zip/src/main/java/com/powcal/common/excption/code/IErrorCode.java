package com.powcal.common.excption.code;

import java.io.Serializable;
import java.util.Objects;


/**
 *
 */
public interface IErrorCode extends Serializable {

    /**
     * 错误模块
     */
    int getModuleCode();


    /**
     * 错误消息
     */
    String getMessage();

    /**
     * 错误code码
     */
    int getCode();

    default Integer getFullCode() {
        if (Objects.equals(getCode(), 100)) {
            return getCode();
        }
        return Integer.parseInt(getModuleCode() + "" + getCode());
    }

}
