package com.powcal.common.excption;

import com.powcal.common.excption.code.IErrorCode;
import com.powcal.common.excption.code.SystemCode;
import lombok.Getter;

/**
 * @author wangkun
 * @Description: 通用异常类
 * @email lkn5434@163.com
 * @date 2024/4/19
 */
public class BusinessException extends RuntimeException {
    private static final long serialVersionUID = 2359767895161832954L;

    @Getter
    private final int code;

    public BusinessException(String message) {
        super(message);
        this.code = SystemCode.FAILURE.getCode();
    }

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    /**
     * code为resultCode的模块code拼接错误code
     *
     * @param resultCode 错误编码
     */
    public BusinessException(IErrorCode resultCode) {
        super(resultCode.getMessage());
        this.code = resultCode.getFullCode();
    }

    /**
     * 提高性能
     *
     * @return Throwable
     */
    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
