package com.powcal.common.eunm;

import lombok.Getter;

/**
 * @author wangkun
 * @Description: 数据分类
 * @email lkn5434@163.com
 * @date 2024/4/17
 */
@Getter
public enum DataStepEnum {

    DQ1DAY("DQ1DAY"),
    DQ4DAY("DQ4DAY"),
    CDQ4H("CDQ4H"),
    CDQ15MIN("CDQ15MIN"),
    DQ("DQ"),
    CDQ("CDQ"),
    ALL("ALL")
    ;

    private final String code;

    DataStepEnum(String code) {
        this.code = code;
    }
}
