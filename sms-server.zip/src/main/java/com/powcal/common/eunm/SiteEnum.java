package com.powcal.common.eunm;

import com.powcal.common.state.State;
import com.powcal.common.state.gd.GdyjxsState;
import com.powcal.common.state.gd.GdyjxyaState;
import com.powcal.common.state.gd.GdyjxybState;
import com.powcal.common.state.js.JScjxhfdState;
import lombok.Getter;

/**
 * @Author 喻俊杰
 * @Date:2024/10/15
 * @Description:
 */
@Getter
public enum SiteEnum {
    GDYJXS("GDYJXS", new GdyjxsState()),
    GDYJXYA("GDYJXS", new GdyjxyaState()),
    GDYJXYB("GDYJXS", new GdyjxybState()),
    CJXHFD( "CJXHFD", new JScjxhfdState());
    private String code;
    private  State state;

    SiteEnum(String code, State state) {
        this.code = code;
        this.state = state;
    }


    public static State getState(String site) {
        return SiteEnum.valueOf(site).state;
    }
}
