package com.powcal.common.eunm;

import lombok.Getter;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author wangkun
 * @Description: 时间分类
 * @email lkn5434@163.com
 * @date 2024/4/17
 */
@Getter
public enum ReportTimeEnum {

    YYYY_MM("YYYY-MM"),
    YYYY_IW("YYYY-IW"),
    YYYY_MM_dd("YYYY-MM-dd"),

    ;

    private String code;

    ReportTimeEnum(String code) {
        this.code = code;
    }

    public static Optional<ReportTimeEnum> getByCode(String code) {
        if (code == null || code.isBlank()) {
            return Optional.empty();
        }
        return Arrays.stream(ReportTimeEnum.values()).filter(e -> e.code.equals(code)).findFirst();
    }
}
