package com.powcal.handler;


import com.powcal.error.RoseException;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;

public class RoseExceptionHandler {
    public static final String EMPTY_MSG = "";

    public static void prompt(int code) {
        handle(code, EMPTY_MSG, LogLevel.OFF);
    }

    public static void prompt(int code, String msg) {
        handle(code, msg, LogLevel.OFF);
    }

    public static void debug(int code) {
        handle(code, EMPTY_MSG, LogLevel.DEBUG);
    }

    public static void debug(int code, String msg) {
        handle(code, msg, LogLevel.DEBUG);
    }


    public static void info(int code) {
        handle(code, EMPTY_MSG, LogLevel.INFO);
    }

    public static void info(int code, String msg) {
        handle(code, msg, LogLevel.INFO);
    }

    public static void warn(int code) {
        handle(code, EMPTY_MSG, LogLevel.WARN);
    }

    public static void warn(int code, String msg) {
        handle(code, msg, LogLevel.WARN);
    }

    public static void warn(int code, String msg, Throwable t) {
        handle(code, msg, LogLevel.WARN, t);
    }

    public static void error(int code) {
        handle(code, EMPTY_MSG, LogLevel.ERROR);
    }

    public static void error(int code, String msg) {
        handle(code, msg, LogLevel.ERROR);
    }

    public static void error(int code, String msg, Throwable t) {
        handle(code, msg, LogLevel.ERROR, t);
    }

    public static void handle(int code, String msg, LogLevel level) {
        handle(code, msg, level, null);
    }

    public static void handle(HttpStatus httpStatus, int code, String msg, LogLevel level) {
        handle(httpStatus, code, msg, level, null);
    }

    public static void handle(int code, String msg, LogLevel level, Throwable t) {
        if (t == null) {
            throw new RoseException(code, msg, level);
        }
        throw new RoseException(code, msg, level, t);
    }

    public static void handle(HttpStatus httpStatus, int code, String msg, LogLevel level, Throwable t) {
        if (t == null) {
            throw new RoseException(httpStatus, code, msg, level);
        }
        throw new RoseException(httpStatus, code, msg, level, t);
    }

}
