package com.powcal.handler.abstractPoint;

import com.powcal.handler.basic.AbstractHandler;
import com.powcal.handler.basic.Handler;
import lombok.extern.slf4j.Slf4j;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 数据标准化
 */
@Slf4j
public abstract class AbstractStandardizationHandler<T> extends AbstractHandler<T>  {


}
