package com.powcal.handler.basic;

import com.powcal.annotation.BusinessTypeEnum;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 责任链上下文
 */
@Component
public class HandlersContext {

    @Autowired
    private BaseHandler baseHandler;
    private Map<String,Map<Integer ,Handler>> handlers =new HashMap<>();

    @Getter
    private AbstractHandler startHandler;
    protected void setHandlers(String key,Integer index,Handler handler){
        Map<Integer, Handler> integerHandlerMap = handlers.get(key);
        Map<Integer, Handler> handlerMap =integerHandlerMap==null? new HashMap<>():integerHandlerMap;
        handlerMap.put(index,handler);
        handlers.put(key,handlerMap);
    };
    protected Map<Integer ,Handler> getHandler(String key){
        return handlers.get(key);
    }
    protected void build(){
        Map<Integer, Handler> handler1 = getHandler(BusinessTypeEnum.Filter.getValue());
        AbstractHandler.Builder builder = new AbstractHandler.Builder();
        Stream<Integer> sorted1 = handler1.keySet().stream().sorted();
        sorted1.forEach((k) -> {
            builder.addHandler((AbstractHandler) handler1.get(k));
        });

        Map<Integer, Handler> handler2 = getHandler(BusinessTypeEnum.Standardization.getValue());
        Stream<Integer> sorted2 = handler2.keySet().stream().sorted();
        sorted2.forEach((k) -> {
            builder.addHandler((AbstractHandler) handler2.get(k));
        });
        builder.addHandler(baseHandler);
        this.startHandler=builder.build();
    }

}
