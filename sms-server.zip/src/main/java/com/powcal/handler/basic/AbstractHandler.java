package com.powcal.handler.basic;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 抽象节点类
 */
@Slf4j
public abstract class AbstractHandler<T> implements Handler<T>{

    @Getter
    private Handler nextHandler;

    @Override
    public void doHandler(T t) {
        log.warn("未定义的操作");
    }

    @Override
    public Handler doHandleReturnNextHandler(T t) {
        doHandler(t);
        return getNextHandler();
    }

    private void next(Handler handler) {
        this.nextHandler=handler;
    }

    public static class Builder<T>{

        private AbstractHandler<T> head;
        private AbstractHandler<T> tail;

        public Builder<T> addHandler(AbstractHandler<T> handler){
            if(this.head==null){
                this.head=this.tail=handler;
                return this;
            }
            this.tail.next(handler);
            this.tail=handler;
            return this;
        }

        public AbstractHandler<T> build(){
            // 添加默认的流程结尾
            AbstractHandler baseHandler=new BaseHandler();
            if(this.tail!=null){
                this.tail.next(baseHandler);
                this.tail=baseHandler;
            }
            if(this.head==null){
                this.head=baseHandler;
            }
            return this.head;
        }


    }

}
