package com.powcal.handler.basic;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 处理类
 */
public interface Handler <T>{

    void doHandler(T t);

    Handler doHandleReturnNextHandler(T t);

}
