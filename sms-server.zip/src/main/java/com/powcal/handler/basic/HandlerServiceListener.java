package com.powcal.handler.basic;



import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.config.EnvironmentProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Author 喻俊杰
 * @Date:2024/5/17
 * @Description: 初始化责任链上下文
 */
@Component
public class HandlerServiceListener implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private EnvironmentProperties environmentProperties;
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        Map<String, Object> envs = event.getApplicationContext().getBeansWithAnnotation(EnvironmentHandler.class);
        HandlersContext handlersContext = event.getApplicationContext().getBean(HandlersContext.class);
        for (String name : envs.keySet()) {
            Handler bean = (Handler)envs.get(name);
            if (bean.getClass().isAnnotationPresent(BusinessHandler.class)) {
                Class<? extends Handler> aClass = bean.getClass();
                EnvironmentHandler annotation = aClass.getAnnotation(EnvironmentHandler.class);
                if(annotation.value().getValue().equals("all")||environmentProperties.getArea().equals(annotation.value().getValue())){
                    BusinessHandler annotation1 = aClass.getAnnotation(BusinessHandler.class);
                    handlersContext.setHandlers(annotation1.value().getValue(),annotation1.index(), bean);
                }
            }
        }
        handlersContext.build();
    }


}
