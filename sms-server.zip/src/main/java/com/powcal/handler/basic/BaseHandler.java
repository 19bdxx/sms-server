package com.powcal.handler.basic;

import com.powcal.broker104.J60870MonitorRecordEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 默认尾节点
 */
@Service
@Slf4j
public class BaseHandler extends AbstractHandler<J60870MonitorRecordEntity>{

    @Override
    public void doHandler(J60870MonitorRecordEntity j60870MonitorRecordEntity) {
        log.info("数据清洗结束");
    }

    @Override
    public Handler doHandleReturnNextHandler(J60870MonitorRecordEntity j60870MonitorRecordEntity) {
        return null;
    }
}
