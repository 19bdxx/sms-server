package com.powcal.handler.filter.js;

import cn.hutool.extra.spring.SpringUtil;
import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870ClientListener;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.handler.filter.BusHandler;
import com.powcal.service.DataPlusService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 江苏业务处理节点
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.js)
@BusinessHandler(value = BusinessTypeEnum.Filter, index = 1)
@Service
@Slf4j
public class JSBusHandler extends BusHandler {

    @Override
    public void doHandler(List<J60870MonitorRecordEntity> docList) {
        try {
            List<J60870MonitorRecordEntity> powcalSitepowList = null;
            List<J60870MonitorRecordEntity> powcalFjpowList = null;
            List<J60870MonitorRecordEntity> powcalCftwindList = null;
            List<J60870MonitorRecordEntity> powcalSitetherpowList = null;
            if (docList != null && docList.size() > 0) {
                LocalDate capDate = J60870ClientListener.now.toLocalDate().plusDays(-1);
                DataPlusService dataPlusService = SpringUtil.getBean("dataPlusService", DataPlusService.class);
                Map<String, Map<String, String>> monitoringPoint = dataPlusService.getMonitoringPoint(capDate);
                powcalSitepowList = new ArrayList<>();
                powcalFjpowList = new ArrayList<>();
                powcalCftwindList = new ArrayList<>();
                powcalSitetherpowList = new ArrayList<>();
                for (J60870MonitorRecordEntity doc : docList) {
                    Map<String, String> stringStringMap = monitoringPoint.get(doc.getMonitoringPoint());
                    if (stringStringMap != null) {
                        String SITE = stringStringMap.get("SITES");
                        String DEVICE_TYPE = stringStringMap.get("DEVICE_TYPE");
                        String POINT_TYPE = stringStringMap.get("POINT_TYPE");
                        String FAN_NUMBER = stringStringMap.get("FAN_NUMBER");
                        String FAN_CODE = stringStringMap.get("FAN_CODE");
                        String FJ_HEIGHT = stringStringMap.get("FJ_HEIGHT");
                        String IS_MODEL = stringStringMap.get("IS_MODEL");
                        String POW_VALUE = stringStringMap.get("POW_VALUE");
                        doc.setPowValue(POW_VALUE);
                        doc.setSiteid(SITE);
                        doc.setDeviceType(DEVICE_TYPE);
                        doc.setPointType(POINT_TYPE);
                        doc.setFan_code(FAN_CODE);//012080
                        doc.setFan_number(FAN_NUMBER);//#12
                        doc.setFJ_HEIGHT(FJ_HEIGHT);
                        doc.setIs_model(IS_MODEL);

                        if (DEVICE_TYPE.equals("SYZ")) {//场站功率监测数据表【POWCAL_SITEPOW】
                            powcalSitepowList.add(doc);
                        } else if (DEVICE_TYPE.equals("FJ")) {//风机功率监测数据表
                            powcalFjpowList.add(doc);
                        } else if (POINT_TYPE.equals("SPEED") || POINT_TYPE.equals("DIRECTION") || POINT_TYPE.equals("SPEED_H") || POINT_TYPE.equals("DIRECTION_H") || POINT_TYPE.equals("SPEED_AVG") || POINT_TYPE.equals("DIRECTION_AVG") || POINT_TYPE.equals("SPEED_SDH")) {//测风塔不同高度风速风向
                            powcalCftwindList.add(doc);
                        } else if (POINT_TYPE.equals("PRESSURE") || POINT_TYPE.equals("HUMIDITY") || POINT_TYPE.equals("TEMPERATURE")) {//场站(测风塔or激光雷达)温度
                            powcalSitetherpowList.add(doc);
                        }
                    }
                }

            }
            getNextHandler().doHandleReturnNextHandler(powcalSitepowList)
                    .doHandleReturnNextHandler(powcalFjpowList)
                    .doHandleReturnNextHandler(powcalCftwindList).
                    doHandleReturnNextHandler(powcalSitetherpowList);
        }catch (Exception e){
            log.error(e.getMessage());
        }
    }
}
