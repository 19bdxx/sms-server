package com.powcal.handler.filter;

import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.handler.abstractPoint.AbstractFilterHandler;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 基础过滤器
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.all)
@BusinessHandler(value = BusinessTypeEnum.Filter, index = 0)
@Service
public class BasicHandler extends AbstractFilterHandler<List<J60870MonitorRecordEntity>> {
    @Override
    public void doHandler(List<J60870MonitorRecordEntity> list) {
        //写一些基础通用的操作
        getNextHandler().doHandler(list);
    }


}
