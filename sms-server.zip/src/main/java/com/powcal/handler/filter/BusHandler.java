package com.powcal.handler.filter;

import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.handler.abstractPoint.AbstractFilterHandler;

import java.util.List;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 业务过滤器
 */
public class BusHandler  extends AbstractFilterHandler<List<J60870MonitorRecordEntity>> {

}
