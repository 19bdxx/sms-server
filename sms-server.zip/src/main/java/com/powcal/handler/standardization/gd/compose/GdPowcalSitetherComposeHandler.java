package com.powcal.handler.standardization.gd.compose;

import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalSitetherEntity;
import com.powcal.handler.basic.Handler;
import com.powcal.handler.abstractPoint.AbstractStandardizationHandler;
import com.powcal.service.PowcalSitetherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 广东场站温度表组合节点
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.gd)
@BusinessHandler(value = BusinessTypeEnum.Standardization, index = 4)
@Service
public class GdPowcalSitetherComposeHandler extends AbstractStandardizationHandler<List<J60870MonitorRecordEntity>> {
    @Autowired
    public PowcalSitetherService powcalSitetherService;



    @Override
    public Handler doHandleReturnNextHandler(List<J60870MonitorRecordEntity> j60870MonitorRecordEntities) {
        savePowcalSitetherpow(j60870MonitorRecordEntities);
        return getNextHandler();
    }

    public void savePowcalSitetherpow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalSitetherEntity> powcalSitetherTempMap = pendingList.stream().collect(Collectors.toMap(
                monitorRecordDoc -> {
                    // 使用场站、监测时间作为组合键
                    return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getCreateTime();
                },
                monitorRecordDoc -> {
                    // 创建一个新的Map来存储合并后的数据
                    PowcalSitetherEntity powcalSitetherEntity = new PowcalSitetherEntity();
                    powcalSitetherEntity.setSiteId(monitorRecordDoc.getSiteid());
                    powcalSitetherEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                    if ("TEMPERATURE".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_t(monitorRecordDoc.getMonitoringValue());
                    } else if ("HUMIDITY".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_h(monitorRecordDoc.getMonitoringValue());
                    } else if ("PRESSURE".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_p(monitorRecordDoc.getMonitoringValue());
                    }
                    return powcalSitetherEntity;
                },
                // 合并函数
                (existingData, newData) -> {
                    if (newData.getWt_p() != null) {
                        existingData.setWt_p(newData.getWt_p());
                    }
                    if (newData.getWt_h() != null) {
                        existingData.setWt_h(newData.getWt_h());
                    }
                    if (newData.getWt_t() != null) {
                        existingData.setWt_t(newData.getWt_t());
                    }
                    return existingData;
                }
        ));
        powcalSitetherService.saveBatch(new ArrayList<>(powcalSitetherTempMap.values()));
    }
}
