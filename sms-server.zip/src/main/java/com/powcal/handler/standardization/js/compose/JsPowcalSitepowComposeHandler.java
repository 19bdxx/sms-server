package com.powcal.handler.standardization.js.compose;

import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.handler.abstractPoint.AbstractStandardizationHandler;
import com.powcal.handler.basic.Handler;
import com.powcal.service.PowcalSitepowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 江苏升压站组合节点
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.js)
@BusinessHandler(value = BusinessTypeEnum.Standardization, index = 1)
@Service
public class JsPowcalSitepowComposeHandler extends AbstractStandardizationHandler<List<J60870MonitorRecordEntity>> {


    @Autowired
    private PowcalSitepowService powcalSitepowService;



    @Override
    public Handler doHandleReturnNextHandler(List<J60870MonitorRecordEntity> j60870MonitorRecordEntities) {
        savePowcalSitepow(j60870MonitorRecordEntities);
        return getNextHandler();
    }

    public void savePowcalSitepow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalSitepowEntity> PowcalSitepowTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、监测时间和设备类型作为组合键
                            return monitorRecordDoc.getSiteid() + ":" +
                                    monitorRecordDoc.getCreateTime();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalSitepowEntity powcalSitepowEntity = new PowcalSitepowEntity();
                            powcalSitepowEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalSitepowEntity.setHappenTime(monitorRecordDoc.getCreateTime());
                            powcalSitepowEntity.setQckjrl(monitorRecordDoc.getPowValue());
                            if ("ACTIVE_TOTAL".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setActivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE_TOTAL".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setReactivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AVC_REACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setRelimitPower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AGC_ACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setLimitPower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AVC_VOLTAGE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setAvcDy(monitorRecordDoc.getMonitoringValue());
                            } else if ("ACTIVE_ONE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setActivePowerOne(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE_ONE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setReactivePowerOne(monitorRecordDoc.getMonitoringValue());
                            }

                            return powcalSitepowEntity;
                        },
                        // 合并函数，当两个对象具有相同的组合键时调用
                        (existingData, newData) -> {
                            if (existingData.getActivePowertoDouble()!=null) {
                                double active_power =  existingData.getActivePowertoDouble();
                                existingData.setActivePower(String.valueOf(active_power));
                            }
                            if (newData.getLimitPower() != null) {
                                existingData.setLimitPower(newData.getLimitPower());
                            }
                            if (newData.getRelimitPower() != null) {
                                existingData.setRelimitPower(newData.getRelimitPower());
                            }
                            if (newData.getAvcDy() != null) {
                                existingData.setAvcDy(newData.getAvcDy());
                            }
                            return existingData;
                        }
                ));
        powcalSitepowService.saveBatch(new ArrayList<>(PowcalSitepowTempMap.values()));
    }
}
