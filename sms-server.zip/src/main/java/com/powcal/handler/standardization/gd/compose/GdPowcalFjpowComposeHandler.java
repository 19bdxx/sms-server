package com.powcal.handler.standardization.gd.compose;

import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalFjpowEntity;
import com.powcal.handler.basic.Handler;
import com.powcal.handler.abstractPoint.AbstractStandardizationHandler;
import com.powcal.service.PowcalFjpowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 广东风机组合节点
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.gd)
@BusinessHandler(value = BusinessTypeEnum.Standardization, index = 2)
@Service
public class GdPowcalFjpowComposeHandler extends AbstractStandardizationHandler<List<J60870MonitorRecordEntity>> {

    @Autowired
    private PowcalFjpowService powcalFjpowService;



    @Override
    public Handler doHandleReturnNextHandler(List<J60870MonitorRecordEntity> j60870MonitorRecordEntities) {
        savePowcalFjpow(j60870MonitorRecordEntities);
        return getNextHandler();
    }

    public void savePowcalFjpow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalFjpowEntity> PowcalFjpowTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、风机编号、监测时间作为组合键
                            return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getFan_code() + ":" + monitorRecordDoc.getCreateTime();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalFjpowEntity powcalFjpowEntity = new PowcalFjpowEntity();
                            powcalFjpowEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalFjpowEntity.setFannumber(monitorRecordDoc.getFan_number());
                            powcalFjpowEntity.setFanCode(monitorRecordDoc.getFan_code());
                            powcalFjpowEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                            powcalFjpowEntity.setTemplateMachineFlag(monitorRecordDoc.getIs_model());
                            if ("ACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setActivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setReactivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setWinddirection(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setWindSpeed(monitorRecordDoc.getMonitoringValue());
                            } else if ("STATUS".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setStatus(monitorRecordDoc.getMonitoringValue());
                            }
                            return powcalFjpowEntity;
                        },
                        // 合并函数
                        (existingData, newData) -> {
                            if (newData.getTemplateMachineFlag() != null) {
                                existingData.setTemplateMachineFlag(newData.getTemplateMachineFlag());
                            }
                            if (newData.getActivePower() != null) {
                                existingData.setActivePower(newData.getActivePower());
                            }
                            if (newData.getReactivePower() != null) {
                                existingData.setReactivePower(newData.getReactivePower());
                            }
                            if (newData.getWinddirection() != null) {
                                existingData.setWinddirection(newData.getWinddirection());
                            }
                            if (newData.getWindSpeed() != null) {
                                existingData.setWindSpeed(newData.getWindSpeed());
                            }
                            if (newData.getStatus() != null) {
                                existingData.setStatus(newData.getStatus());
                            }
                            return existingData;
                        }
                ));
        powcalFjpowService.saveBatch(new ArrayList<>(PowcalFjpowTempMap.values()));
    }

}
