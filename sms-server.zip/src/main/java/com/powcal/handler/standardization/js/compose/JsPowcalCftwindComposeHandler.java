package com.powcal.handler.standardization.js.compose;

import com.powcal.annotation.BusinessHandler;
import com.powcal.annotation.BusinessTypeEnum;
import com.powcal.annotation.EnvironmentHandler;
import com.powcal.annotation.EnvironmentTypeEnum;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalCftwindEntity;
import com.powcal.handler.abstractPoint.AbstractStandardizationHandler;
import com.powcal.handler.basic.Handler;
import com.powcal.service.PowcalCftwindService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 江苏测风塔风速表组合节点
 */
@EnvironmentHandler(value = EnvironmentTypeEnum.js)
@BusinessHandler(value = BusinessTypeEnum.Standardization, index = 3)
@Service
@Slf4j
public class JsPowcalCftwindComposeHandler extends AbstractStandardizationHandler<List<J60870MonitorRecordEntity>> {

    @Autowired
    public PowcalCftwindService powcalCftwindService;



    @Override
    public Handler doHandleReturnNextHandler(List<J60870MonitorRecordEntity> j60870MonitorRecordEntities) {
        savePowcalCftwind(j60870MonitorRecordEntities);
        return getNextHandler();
    }


    public void savePowcalCftwind(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalCftwindEntity> powcalCftwindTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、位置、监测时间和设备类型作为组合键
                            return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getFJ_HEIGHT() + ":" + monitorRecordDoc.getCreateTime() + ":" + monitorRecordDoc.getDeviceType();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalCftwindEntity powcalCftwindEntity = new PowcalCftwindEntity();
                            powcalCftwindEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalCftwindEntity.setLocation(monitorRecordDoc.getDeviceType());
                            powcalCftwindEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                            powcalCftwindEntity.setLocation(monitorRecordDoc.getFJ_HEIGHT());
                            String pointType = monitorRecordDoc.getPointType();
                            if ("SPEED_H".equals(pointType) || "SPEED".equals(pointType)) {
                                powcalCftwindEntity.setWs(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION_H".equals(pointType) || "DIRECTION".equals(pointType)) {
                                powcalCftwindEntity.setWdir(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION_AVG".equals(pointType)) {
                                powcalCftwindEntity.setSpWdir(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED_AVG".equals(pointType)) {
                                powcalCftwindEntity.setSpWs(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED_SDH".equals(pointType)) {
                                powcalCftwindEntity.setPzc(monitorRecordDoc.getMonitoringValue());
                            }

                            return powcalCftwindEntity;
                        },
                        // 合并函数，当两个对象具有相同的组合键时调用
                        (existingData, newData) -> {
                            if (newData.getWs() != null) {
                                existingData.setWs(newData.getWs());
                            }
                            if (newData.getWdir() != null) {
                                existingData.setWdir(newData.getWdir());
                            }
                            if (newData.getPzc() != null) {
                                existingData.setPzc(newData.getPzc());
                            }
                            if (newData.getSpWdir() != null) {
                                existingData.setSpWdir(newData.getSpWdir());
                            }
                            if (newData.getSpWs() != null) {
                                existingData.setSpWs(newData.getSpWs());
                            }
                            return existingData;
                        }
                ));
        powcalCftwindService.saveBatch(new ArrayList<>(powcalCftwindTempMap.values()));
    }


}
