package com.powcal.mapper;

import com.powcal.entity.PowcalFjpowEntity;
import com.powcal.entity.dto.FjavgSpeedDto;
import com.powcal.mapper.base.IPlusMapper;
import org.apache.ibatis.annotations.Mapper;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface PowcalFjpowMapper extends IPlusMapper<PowcalFjpowEntity> {
    List<FjavgSpeedDto> getFjAvgSpeedOfTime(String siteid, LocalDateTime startTime, LocalDateTime endTime);

}
