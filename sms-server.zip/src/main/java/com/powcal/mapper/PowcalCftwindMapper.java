package com.powcal.mapper;

import com.powcal.entity.PowcalCftwindEntity;
import com.powcal.mapper.base.IPlusMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PowcalCftwindMapper extends IPlusMapper<PowcalCftwindEntity> {
}
