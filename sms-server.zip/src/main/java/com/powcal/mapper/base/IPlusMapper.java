package com.powcal.mapper.base;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.io.Serializable;

public interface IPlusMapper<T> extends BaseMapper<T> {
    T selectForUpdate(Serializable id);
}