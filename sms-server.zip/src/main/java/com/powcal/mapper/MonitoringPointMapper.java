package com.powcal.mapper;

import com.powcal.entity.MonitoringPointEntity;
import com.powcal.entity.dto.SiteMonitoringPointsDto;
import com.powcal.mapper.base.IPlusMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface MonitoringPointMapper extends IPlusMapper<MonitoringPointEntity> {

    /**
     * author：liuxianying
     * time：2023-10-20
     */
    @Select("SELECT M.SITES, S.POWER_DISPATCH_ORG, LISTAGG(M.MONITORING_POINT, ',') WITHIN GROUP (ORDER BY M.MONITORING_POINT) AS MONITORING_POINT\n" +
            "FROM SITE_BASIC AS S\n" +
            "LEFT JOIN MONITORING_POINT AS M ON S.SITE_CODE = M.SITES\n" +
            "WHERE M.SITES = #{sites}\n" +
            "GROUP BY M.SITES, S.POWER_DISPATCH_ORG;")
    SiteMonitoringPointsDto SelectSiteMonitoringPoint(String sites);


    @Select("select count(*) from MONITORING_POINT where sites = #{sites} and STATUS = 'USING'")
    int usingPointCountOfsite(String sites);

    @Select("select nvl(p.pow_value,site.TYZJRL) as POW_VALUE,s1.IS_MODEL||s2.IS_MODEL||s3.IS_MODEL||s4.IS_MODEL||s5.IS_MODEL as IS_MODEL,m.MONITORING_POINT as MONITORING_POINT,m.SITES as SITES,m.DEVICE_TYPE AS DEVICE_TYPE,m.POINT_TYPE AS POINT_TYPE,(f.name||f1.name||f2.name||f3.name||f4.name) as fj_height,s1.FAN_CODE||s2.FAN_CODE||s3.FAN_CODE||s4.FAN_CODE||s5.FAN_CODE as fan_code,s1.FJ_CODE||s2.FJ_CODE||s3.FJ_CODE||s4.FJ_CODE||s5.FJ_CODE as fan_number\n" +
            "\n" +
            "              from MONITORING_POINT m \n" +
            "              \n" +
            "            left join (select e1.*,fj.IS_MODEL,fj.FJ_CODE from site_basic_fan e1 left join fj_data fj on fj.SORTCODE=e1.FAN_CODE) s1 on s1.REACTIVE=m.MONITORING_POINT\n" +
            "\n" +
            "            left join (select e1.*,fj.IS_MODEL,fj.FJ_CODE from site_basic_fan e1 left join fj_data fj on fj.SORTCODE=e1.FAN_CODE) s2 on s2.ACTIVE=m.MONITORING_POINT\n" +
            "\n" +
            "            left join (select e1.*,fj.IS_MODEL,fj.FJ_CODE from site_basic_fan e1 left join fj_data fj on fj.SORTCODE=e1.FAN_CODE) s3 on s3.WDIR=m.MONITORING_POINT\n" +
            "\n" +
            "            left join (select e1.*,fj.IS_MODEL,fj.FJ_CODE from site_basic_fan e1 left join fj_data fj on fj.SORTCODE=e1.FAN_CODE) s4 on s4.WS=m.MONITORING_POINT\n" +
            "\n" +
            "            left join (select e1.*,fj.IS_MODEL,fj.FJ_CODE from site_basic_fan e1 left join fj_data fj on fj.SORTCODE=e1.FAN_CODE) s5 on s5.STATE=m.MONITORING_POINT\n" +
            "               \n" +
            "            left join site_basic_wt f on f.WDIR=m.MONITORING_POINT\n" +
            "\n" +
            "            left join site_basic_wt f1 on f1.WS=m.MONITORING_POINT\n" +
            "            left join site_basic_wt f2 on f2.PJSP_WDIR=m.MONITORING_POINT\n" +
            "\n" +
            "            left join site_basic_wt f3 on f3.PJSP_WS=m.MONITORING_POINT\n" +
            "            left join site_basic_wt f4 on f4.PJSP_BZC=m.MONITORING_POINT\n" +
            "            LEFT JOIN site_basic site ON\n" +
            "            site.SITE_CODE = m.SITES"+
            "            LEFT JOIN ( select POW_DATE,POW_VALUE,SITE_CODE from site_basic_pow s left join SITE_BASIC b on s.SITEID=b.SITEID where  s.POW_DATE = #{date} AND s.status='ENTERED' and ROWNUM =1 order by s.SUBMIT_TIME desc ) p on p.SITE_CODE=m.SITES\n" +
            "            WHERE  m.STATUS = 'USING'")
    List<Map<String,String>> selectPointInfoByStatus(@Param("date")LocalDate date);

    List<Map> queryUsedPoints(@Param("points") String[] points);
}