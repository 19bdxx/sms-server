package com.powcal.mapper;

import com.powcal.entity.PowcalSitetherEntity;
import com.powcal.mapper.base.IPlusMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PowcalSitetherMapper extends IPlusMapper<PowcalSitetherEntity> {
}
