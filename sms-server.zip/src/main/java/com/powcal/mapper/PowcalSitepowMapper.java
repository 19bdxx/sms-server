package com.powcal.mapper;

import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.mapper.base.IPlusMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PowcalSitepowMapper extends IPlusMapper<PowcalSitepowEntity> {


}
