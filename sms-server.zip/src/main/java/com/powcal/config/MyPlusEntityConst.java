package com.powcal.config;

public interface MyPlusEntityConst {

    String FIELD_CREATE_TIME = "createTime";

    String FIELD_UPDATE_TIME = "updateTime";

    String FIELD_DELETED = "deleted";

}