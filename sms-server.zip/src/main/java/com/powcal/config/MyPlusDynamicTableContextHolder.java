package com.powcal.config;

public class MyPlusDynamicTableContextHolder {
    private static final ThreadLocal<String> dynamicTableLocal = new ThreadLocal<>();

    public static String getTableName() {
        return dynamicTableLocal.get();
    }

    public static void setTableName(String tableName) {
        setTableName(tableName, false);
    }

    public static void setTableName(String tableName, boolean isPersist) {
        if (isPersist) {
            tableName += MybatisPlusConfigure.PERSIST;
        }
        dynamicTableLocal.set(tableName);
    }

    public static void clear() {
        dynamicTableLocal.remove();
    }
}
