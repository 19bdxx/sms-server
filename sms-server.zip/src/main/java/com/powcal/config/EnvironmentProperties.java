package com.powcal.config;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @Author 喻俊杰
 * @Date:2024/5/17
 * @Description: 获取环境区域标识
 */
@Data
@Accessors(chain = true)
@Component
@ConfigurationProperties(prefix = "sms")
public class EnvironmentProperties {
  private String area;
}
