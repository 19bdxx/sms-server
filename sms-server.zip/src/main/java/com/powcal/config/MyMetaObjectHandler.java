package com.powcal.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;


@Component
public class MyMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        Object createTimeVal = getFieldValByName(MyPlusEntityConst.FIELD_CREATE_TIME, metaObject);
        if (createTimeVal == null) {
            this.strictInsertFill(metaObject, MyPlusEntityConst.FIELD_CREATE_TIME, LocalDateTime.class, LocalDateTime.now());
        }
        this.strictInsertFill(metaObject, MyPlusEntityConst.FIELD_DELETED, Integer.class, 0);

    }

    @Override
    public void updateFill(MetaObject metaObject) {
        Object updateTimeVal = getFieldValByName(MyPlusEntityConst.FIELD_UPDATE_TIME, metaObject);
        if (updateTimeVal == null) {
            this.strictUpdateFill(metaObject, MyPlusEntityConst.FIELD_UPDATE_TIME, LocalDateTime.class, LocalDateTime.now());
        }
    }
}
