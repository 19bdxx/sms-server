package com.powcal.config;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Accessors(chain = true)
@Component
@ConfigurationProperties(prefix = "broker104")
public class Broker104Properties {
    public final String BASE_PACKAGE = "com.powcal";
    public String ip;
    public int port;
    public int timeout = 60000;
}
