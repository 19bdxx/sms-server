package com.powcal.broker104;

import ch.qos.logback.core.LogbackException;
import cn.hutool.extra.spring.SpringUtil;
import com.powcal.handler.basic.HandlersContext;
import com.powcal.service.DataPlusService;
import lombok.extern.slf4j.Slf4j;
import org.openmuc.j60870.ASdu;
import org.openmuc.j60870.ASduType;
import org.openmuc.j60870.CauseOfTransmission;
import org.openmuc.j60870.ConnectionEventListener;
import org.openmuc.j60870.ie.IeShortFloat;
import org.openmuc.j60870.ie.IeSinglePointWithQuality;
import org.openmuc.j60870.ie.InformationElement;
import org.openmuc.j60870.ie.InformationObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class J60870ClientListener implements ConnectionEventListener {

    boolean STATUS100 = false;//总召唤状态用于 过滤监听中不是总召唤的值
    static Logger myLogger = LoggerFactory.getLogger("broker104");
    static List<J60870MonitorRecordEntity> docList = null;
    public  static LocalDateTime now = null;

    @Override
    public void newASdu(ASdu aSdu) {
        try {
            ASduType asduType = aSdu.getTypeIdentification();//类型组
            CauseOfTransmission causeOfTransmission = aSdu.getCauseOfTransmission();//操作原因组
            int asduTypeId = asduType.getId();//类型ID   100的含义是总召唤
            int cotId = causeOfTransmission.getId();//操作原因代表的ID,id=7激活确认,id=10 激活结束
            if (asduTypeId == 100 && cotId == 7) {
                log.info("总召唤启动====================================================");
                STATUS100 = true;
                now = LocalDateTime.now().withSecond(0).withNano(0);
                docList = new ArrayList<>();
            }//总召唤启动 更改状态
            if (asduTypeId == 100 && cotId == 10) {
                log.info("总召唤结束====================================================");
                STATUS100 = false;
                log.info("开始数据清洗："+ LocalDateTime.now());
                DataCleaning();
                log.info("数据清洗结束："+ LocalDateTime.now());
            }
            if (STATUS100 && asduTypeId != 100) {
                if (asduTypeId == 1) {  //单点遥信
                    List<HashMap<String, Object>> maps = AsduToMap(aSdu);
                    if (!maps.isEmpty()) {
                        for (HashMap<String, Object> map : maps) {
                            int ioa = (int) map.get("IOA");
                            boolean value = (boolean) map.get("VALUE");
                            String boolValue = value ? "1" : "0";
                            J60870MonitorRecordEntity doc = new J60870MonitorRecordEntity();
                            doc.setCreateTime(now);
                            doc.setMonitoringPoint(ioa + "");
                            doc.setMonitoringValue(boolValue);
                            docList.add(doc);
                            myLogger.info(now + "," + asduTypeId + "," + ioa + "," + boolValue);
                        }
                    }
                } else if (asduTypeId == 13) {  //浮点型遥测
                    List<HashMap<String, Object>> maps = AsduToMap(aSdu);
                    if (!maps.isEmpty()) {
                        for (HashMap<String, Object> map : maps) {
                            int ioa = (int) map.get("IOA");
                            float value = (float) map.get("VALUE");

                            J60870MonitorRecordEntity doc = new J60870MonitorRecordEntity();
                            doc.setCreateTime(now);
                            doc.setMonitoringPoint(ioa + "");
                            doc.setMonitoringValue(value + "");
                            docList.add(doc);
                            myLogger.info(now + "," + asduTypeId + "," + ioa + "," + value);
                        }
                    }
                }
            }

        } catch (LogbackException e) {
            throw new LogbackException("数据接收错误。");
        }
    }

    private List<HashMap<String, Object>> AsduToMap(ASdu aSdu) {
        List<HashMap<String, Object>> maps = new ArrayList<>();
        int id = aSdu.getTypeIdentification().getId();
        InformationObject[] informationObjects = aSdu.getInformationObjects();//获取信息体
        if (id == 1 || id == 13) {
            if (informationObjects.length != 0) {//信息组
                for (InformationObject informationObject : informationObjects) {
                    int IOA = informationObject.getInformationObjectAddress();//组 初始点号
                    InformationElement[][] informationElements = informationObject.getInformationElements(); //点号信息组

                    if (informationElements.length != 0) {

                        for (int i1 = 0; i1 < informationElements.length; i1++) {
                            HashMap<String, Object> map = new HashMap<>();
                            InformationElement[] informationElement = informationElements[i1];
                            if (i1 != 0) {
                                IOA += 1;//点号
                            }
                            map.put("IOA", IOA);
                            if (id == 1) {
                                boolean value = ((IeSinglePointWithQuality) informationElement[0]).isOn();
                                map.put("VALUE", value);
                            } else if (id == 13) {
                                float value = ((IeShortFloat) informationElement[0]).getValue();
                                map.put("VALUE", value);
                            }
                            maps.add(map);
                        }
                    }
                }
            }
        }


        return maps;
    }

    public void DataCleaning(){
        HandlersContext handlersContext = SpringUtil.getBean("handlersContext", HandlersContext.class);
        handlersContext.getStartHandler().doHandler(docList);
    }

    /**
     * 监听连接关闭
     *
     * @param cause
     */
    @Override
    public void connectionClosed(IOException cause) {
        log.error("监听连接中断");
    }

    @Override
    public void dataTransferStateChanged(boolean b) {

    }


}

