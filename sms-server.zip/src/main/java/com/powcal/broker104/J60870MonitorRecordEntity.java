package com.powcal.broker104;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class J60870MonitorRecordEntity {

    @JsonFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    private LocalDateTime createTime;

    private String siteid;//站点id

    private String deviceType;//设备类型

    private String pointType;//测点类型

    private String monitoringPoint;//测点

    private String fan_number;//测点对应的风机名称

    private String fan_code;//测点对应的风机编号

    private String FJ_HEIGHT;//测点对应位置高度

    private String is_model;//是否样板机

    private String monitoringValue;//值

    private String powValue;//全厂开机容量

    private Double cap;//投运装机容量
}
