package com.powcal.broker104;

import cn.hutool.extra.spring.SpringUtil;
import com.powcal.config.Broker104Properties;
import org.openmuc.j60870.CauseOfTransmission;
import org.openmuc.j60870.ClientConnectionBuilder;
import org.openmuc.j60870.Connection;
import org.openmuc.j60870.ie.IeQualifierOfInterrogation;

import java.net.InetAddress;

public abstract class J60870Connection {

    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null || connection.isClosed() || connection.isStopped()) {
            try {
                Broker104Properties broker104Properties  = SpringUtil.getBean("broker104Properties", Broker104Properties.class);
                InetAddress address = InetAddress.getByName(broker104Properties.getIp());
                //创建连接参数对象
                ClientConnectionBuilder clientConnectionBuilder = new ClientConnectionBuilder(address);
                //设置socket的连接超时时间
                clientConnectionBuilder.setConnectionTimeout(broker104Properties.getTimeout());
                //设置socket的连接超时时间
                clientConnectionBuilder.setPort(broker104Properties.getPort());
                connection = clientConnectionBuilder.build();
                //配置数据回调类
                J60870ClientListener listener = new J60870ClientListener();
                connection.startDataTransfer(listener);
            } catch (Exception e) {
                connection = null;
            }
        }
        return connection;
    }

    public static void Interrogation() throws Exception {
        if (getConnection() != null) {
            getConnection().interrogation(1, CauseOfTransmission.causeFor(6), new IeQualifierOfInterrogation(0x14));
        } else
            throw new Exception("链接无效");
    }

    public static void Close() {
        if (getConnection() != null) {
            getConnection().close();
            connection = null;
        }
    }
}
