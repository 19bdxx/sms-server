package com.powcal.annotation;

import java.lang.annotation.*;

/**
 * @Author 喻俊杰
 * @Date:2024/11/15
 * @Description: 数据清洗业务组合注解
 */
@Documented
@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface BusinessHandler {
    BusinessTypeEnum value() ;
    int index() default -1;
}
