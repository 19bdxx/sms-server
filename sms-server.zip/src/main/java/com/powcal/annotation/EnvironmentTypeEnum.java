package com.powcal.annotation;

import lombok.Getter;

/**
 * @Author 喻俊杰
 * @Date:2024/5/17
 * @Description: 环境类型枚举
 */
@Getter
public enum EnvironmentTypeEnum {
    //江苏环境
    js("js"),
    //广东环境
    gd("gd"),

    all("all");
    private final String value;
    EnvironmentTypeEnum(String value) {
        this.value = value;
    }
}
