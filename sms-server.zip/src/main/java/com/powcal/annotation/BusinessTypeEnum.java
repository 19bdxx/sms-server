package com.powcal.annotation;

import lombok.Getter;

/**
 * @Author 喻俊杰
 * @Date:2024/5/17
 * @Description: 数据清洗业务枚举
 */
@Getter
public enum BusinessTypeEnum {
    //数据清洗第一大步
    //异常数据处理
    Exception("exception"),

    //数据清洗第二大步
    //数据过滤
    Filter("filter"),

    //数据清洗第三大步
    //数据标准化
    Standardization("standardization");
    private final String value;
    BusinessTypeEnum(String value) {
        this.value = value;
    }
}
