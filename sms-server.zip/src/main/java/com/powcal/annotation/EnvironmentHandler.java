package com.powcal.annotation;


import com.powcal.annotation.EnvironmentTypeEnum;

import java.lang.annotation.*;

/**
 * @Author 喻俊杰
 * @Date:2024/5/17
 * @Description:
 */
@Documented
@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface EnvironmentHandler {
    //环境，决定了哪种方式去计算
    EnvironmentTypeEnum value();
}
