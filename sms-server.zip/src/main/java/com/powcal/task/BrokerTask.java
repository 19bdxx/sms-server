package com.powcal.task;

import cn.hutool.core.date.LocalDateTimeUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.powcal.broker104.J60870Connection;
import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.service.PowcalSitepowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Component
public class BrokerTask {

    @Autowired
    private PowcalSitepowService powcalSitepowService;

    @Scheduled(cron = "${monitor.cron1}")
    public void monitor1() {
        acceptData();
    }

    @Scheduled(cron = "${monitor.cron2}")
    public void monitor2() {
        acceptData();
    }

    @Scheduled(cron = "${monitor.cron3}")
    public void monitor3() {
        acceptData();
    }

    private void acceptData() {
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime time = LocalDateTimeUtil.now().withSecond(0);
        String localDateTime = df.format(time);

        QueryWrapper<PowcalSitepowEntity> queryWrapper = new QueryWrapper();
        queryWrapper.lambda().eq(PowcalSitepowEntity::getHappenTime, localDateTime);
        List<PowcalSitepowEntity> powcalSitepowEntities = powcalSitepowService.list(queryWrapper);

        if (powcalSitepowEntities.size() > 0) {
            return;
        }
        try {
            J60870Connection.Interrogation();
        } catch (Exception e) {
            log.error("connected error:" + e.getMessage());
        }
    }

}
