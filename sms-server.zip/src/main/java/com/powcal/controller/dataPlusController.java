package com.powcal.controller;

import cn.hutool.core.date.DatePattern;
import com.powcal.mapper.PowcalCftwindMapper;
import com.powcal.result.R;
import com.powcal.result.RespResult;
import com.powcal.service.DataPlusService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @Author 喻俊杰
 * @Date:2024/10/17
 * @Description:
 */
@RestController
@CrossOrigin
@Slf4j
@RequestMapping("/dataplus")
public class dataPlusController {

    @Autowired
    private DataPlusService dataPlusService;

    @RequestMapping("/dataPlus_GD")
    public R<String> dataPlus_GD(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") LocalDateTime startTime, @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")LocalDateTime endTime){
        try {
            dataPlusService.dataPlus_GD(startTime,endTime);
            return R.success();
        } catch (Exception e) {
            log.error("dataPlus_GD 接口错误",e);
            return R.fail(500,e.getMessage());
        }
    }

    @RequestMapping("/dataPlus_manyDay")
    public R<String> dataPlus_manyDay(@DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN) LocalDate startDay,  @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN) LocalDate endDay){
        try {
            dataPlusService.dataPlus_manyDay(startDay,endDay);
            return R.success();
        } catch (Exception e) {
            log.error("dataPlus_manyDay 接口错误",e);
            return R.fail(500,e.getMessage());
        }
    }
}
