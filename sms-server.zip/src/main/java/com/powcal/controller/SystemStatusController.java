package com.powcal.controller;

import com.powcal.result.RespResult;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/system")
public class SystemStatusController {
    @ResponseBody
    @GetMapping(value = "/status")
    public RespResult statusInfo() {
        RespResult respResult=new RespResult();
        respResult.setData("");
        respResult.setCode(200);
        return respResult;
    }

}
