package com.powcal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableAsync
@EnableScheduling
@EnableCaching
@SpringBootApplication
public class PowcalApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(PowcalApplication.class, args);

    }


    @Override
    public void run(String... args) throws Exception {
    }

}
