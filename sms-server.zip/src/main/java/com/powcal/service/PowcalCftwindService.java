package com.powcal.service;

import com.powcal.entity.PowcalCftwindEntity;
import com.powcal.mapper.PowcalCftwindMapper;
import com.powcal.service.base.AbstractEntityService;
import org.springframework.stereotype.Service;

@Service
public class PowcalCftwindService  extends AbstractEntityService<PowcalCftwindMapper, PowcalCftwindEntity> {
}
