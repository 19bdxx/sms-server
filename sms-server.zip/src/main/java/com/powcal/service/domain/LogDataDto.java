package com.powcal.service.domain;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @Author 喻俊杰
 * @Date:2024/10/17
 * @Description:
 */
@Data
public class LogDataDto {
    private LocalDateTime time;
    private String type;
    private String point;
    private String value;
}
