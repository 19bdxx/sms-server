package com.powcal.service;

import com.powcal.entity.PowcalFjpowEntity;
import com.powcal.mapper.PowcalFjpowMapper;
import com.powcal.service.base.AbstractEntityService;
import org.springframework.stereotype.Service;

@Service
public class PowcalFjpowService extends AbstractEntityService<PowcalFjpowMapper, PowcalFjpowEntity> {
}
