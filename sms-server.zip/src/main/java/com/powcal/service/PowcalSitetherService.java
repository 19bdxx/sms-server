package com.powcal.service;

import com.powcal.entity.PowcalSitetherEntity;
import com.powcal.mapper.PowcalSitetherMapper;
import com.powcal.service.base.AbstractEntityService;
import org.springframework.stereotype.Service;

@Service
public class PowcalSitetherService extends AbstractEntityService<PowcalSitetherMapper, PowcalSitetherEntity> {
}
