package com.powcal.service;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.ZipUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.powcal.broker104.J60870MonitorRecordEntity;
import com.powcal.entity.PowcalCftwindEntity;
import com.powcal.entity.PowcalFjpowEntity;
import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.entity.PowcalSitetherEntity;
import com.powcal.mapper.*;
import com.powcal.service.domain.LogDataDto;
import com.powcal.utils.CollUtils;
import com.powcal.utils.JavaTimeUtils;
import com.powcal.utils.StrUtils;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Slf4j
public class DataPlusService {

    @Autowired
    public MonitoringPointMapper mapper;
    @Value("${logging.file.path}")
    public String path;
    @Autowired
    public PowcalSitepowService powcalSitepowService;
    @Autowired
    public PowcalFjpowService powcalFjpowService;
    @Autowired
    public PowcalCftwindService powcalCftwindService;
    @Autowired
    public PowcalSitetherService powcalSitetherService;

    @Autowired
    public PowcalSitepowMapper powcalSitepowMapper;

    @Autowired
    public PowcalFjpowMapper powcalFjpowMapper;

    @Autowired
    public PowcalCftwindMapper powcalCftwindMapper;

    @Autowired
    public PowcalSitetherMapper powcalSitetherMapper;

    public Map<String, Map<String, String>> getMonitoringPoint(LocalDate capDate) {
        List<Map<String, String>> list = mapper.selectPointInfoByStatus(capDate);
        return list.stream()
                .collect(Collectors.toMap(
                        map -> map.get("MONITORING_POINT"), // 使用 "key1" 的值作为新 Map 的 key
                        map -> map // 使用原始的 Map 作为新 Map 的 value
                ));
    }

    public void dataPlus_GD(LocalDateTime startTime, LocalDateTime endTime) throws Exception {

        String fileName = "data" + JavaTimeUtils.format(startTime.toLocalDate(), "yyyyMMdd") + ".log";
        String fileType = ".zip";
        String filePath = path + "/data/" + fileName + fileType;
        File unzip = null;

        //原始数据
        List<String> lineList = null;
        Stream<String> inputStream = null;
        try {
            unzip = ZipUtil.unzip(filePath, StandardCharsets.UTF_8);
            inputStream = Files.lines(Paths.get(path + "/data/" + fileName + "/" + fileName), StandardCharsets.UTF_8);
            FileUtil.del(path + "/data/" + fileName);
        } catch (Exception E) {
            if (unzip != null) {
                unzip.delete();
            }
            log.error(E.getMessage(), E);
            inputStream = Files.lines(Paths.get(path + "/data/" + fileName), StandardCharsets.UTF_8);
            //lineList = FileUtils.readLines();
        }
        List<J60870MonitorRecordEntity> PowcalSitepowList = new ArrayList<>();//场站（升压站）功率监测
        List<J60870MonitorRecordEntity> PowcalFjpowList = new ArrayList<>();//风机功率监测
        List<J60870MonitorRecordEntity> PowcalCftwindList = new ArrayList<>();//测风塔风速
        List<J60870MonitorRecordEntity> PowcalSitetherpowList = new ArrayList<>();//场站(测风塔or激光雷达)温度
        Map<String, Map<String, String>> monitoringPoint11 = getMonitoringPoint(startTime.toLocalDate());


        if (inputStream != null) {
            List<LogDataDto> list = inputStream.parallel().filter(line -> {
                List<String> colList = StrUtils.split(line, ",");
                if (CollUtils.size(colList) > 3) {
                    String replace = colList.get(0).replace("T", " ");
                    LocalDateTime recordTime = JavaTimeUtils.parse(replace, "yyyy-MM-dd HH:mm:ss").withSecond(0);
                    return recordTime.isAfter(startTime.plusMinutes(-1)) && recordTime.isBefore(endTime.plusMinutes(1));
                }
                return false;
            }).map(line -> {
                List<String> colList = StrUtils.split(line, ",");
                LogDataDto logDataDto = new LogDataDto();

                String replace = colList.get(0).replace("T", " ");
                LocalDateTime recordTime = JavaTimeUtils.parse(replace, "yyyy-MM-dd HH:mm:ss").withSecond(0);
                logDataDto.setTime(recordTime);
                logDataDto.setType(colList.get(1));
                logDataDto.setPoint(colList.get(2));
                logDataDto.setValue(colList.get(3));
                return logDataDto;
            }).toList();
            list.forEach(logDataDto -> {
                LocalDateTime recordTime = logDataDto.getTime();
                J60870MonitorRecordEntity doc = new J60870MonitorRecordEntity();
                String point = logDataDto.getPoint();
                //补充数据
                Map<String, String> stringStringMap = monitoringPoint11.get(point);
                doc.setCreateTime(recordTime);
                doc.setMonitoringPoint(point);
                doc.setMonitoringValue(logDataDto.getValue());
                if (stringStringMap != null) {
                    String SITE = stringStringMap.get("SITES");
                    String DEVICE_TYPE = stringStringMap.get("DEVICE_TYPE");
                    String POINT_TYPE = stringStringMap.get("POINT_TYPE");
                    String FAN_NUMBER = stringStringMap.get("FAN_NUMBER");
                    String FAN_CODE = stringStringMap.get("FAN_CODE");
                    String FJ_HEIGHT = stringStringMap.get("FJ_HEIGHT");
                    String IS_MODEL = stringStringMap.get("IS_MODEL");
                    String POW_VALUE = stringStringMap.get("POW_VALUE");
                    doc.setPowValue(POW_VALUE);
                    doc.setSiteid(SITE);
                    doc.setDeviceType(DEVICE_TYPE);
                    doc.setPointType(POINT_TYPE);
                    doc.setFan_code(FAN_CODE);//012080
                    doc.setFan_number(FAN_NUMBER);//#12
                    doc.setFJ_HEIGHT(FJ_HEIGHT);
                    doc.setIs_model(IS_MODEL);
                    if (doc != null) {
                        if (DEVICE_TYPE.equals("SYZ")) {//场站功率监测数据表【POWCAL_SITEPOW】
                            PowcalSitepowList.add(doc);
                        } else if (DEVICE_TYPE.equals("FJ")) {//风机功率监测数据表
                            PowcalFjpowList.add(doc);
                        } else if (POINT_TYPE.equals("SPEED") || POINT_TYPE.equals("DIRECTION") || POINT_TYPE.equals("SPEED_H") || POINT_TYPE.equals("DIRECTION_H") || POINT_TYPE.equals("SPEED_AVG") || POINT_TYPE.equals("DIRECTION_AVG") || POINT_TYPE.equals("SPEED_SDH")) {//测风塔不同高度风速风向
                            PowcalCftwindList.add(doc);
                        } else if (POINT_TYPE.equals("PRESSURE") || POINT_TYPE.equals("HUMIDITY") || POINT_TYPE.equals("TEMPERATURE")) {//场站(测风塔or激光雷达)温度
                            PowcalSitetherpowList.add(doc);
                        }
                    }

                }

            });

            try {
                savePowcalSitepow(PowcalSitepowList);
                savePowcalFjpow(PowcalFjpowList);
                savePowcalCftwind(PowcalCftwindList);
                savePowcalSitetherpow(PowcalSitetherpowList);
            } catch (Exception e) {
                log.error("保存错误", e);
                throw new RuntimeException(e);
            }


        }

    }

    public void savePowcalSitepow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalSitepowEntity> PowcalSitepowTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、监测时间和设备类型作为组合键
                            return monitorRecordDoc.getSiteid() + ":" +
                                    monitorRecordDoc.getCreateTime();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalSitepowEntity powcalSitepowEntity = new PowcalSitepowEntity();
                            powcalSitepowEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalSitepowEntity.setHappenTime(monitorRecordDoc.getCreateTime());
                            powcalSitepowEntity.setQckjrl(monitorRecordDoc.getPowValue());
                            if ("ACTIVE_TOTAL".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setActivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE_TOTAL".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setReactivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AVC_REACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setRelimitPower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AGC_ACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setLimitPower(monitorRecordDoc.getMonitoringValue());
                            } else if ("AVC_VOLTAGE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setAvcDy(monitorRecordDoc.getMonitoringValue());
                            } else if ("ACTIVE_ONE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setActivePowerOne(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE_ONE".equals(monitorRecordDoc.getPointType())) {
                                powcalSitepowEntity.setReactivePowerOne(monitorRecordDoc.getMonitoringValue());
                            }

                            return powcalSitepowEntity;
                        },
                        // 合并函数，当两个对象具有相同的组合键时调用
                        (existingData, newData) -> {
                            if (newData.getActivePowerOne() != null) {
                                double existingPower = (existingData.getActivePower() == null ? existingData.getActivePowerOnetoDouble() : existingData.getActivePowertoDouble());
                                double newPower = newData.getActivePowerOnetoDouble();
                                double active_power = existingPower + newPower;
                                existingData.setActivePower(String.valueOf(active_power));
                                existingData.setActivePowerOne(newData.getActivePowerOne());
                            }
                            if (newData.getReactivePowerOne() != null) {
                                double existingPower = (existingData.getReactivePower() == null ? existingData.getReactivePowerOnetoDouble() : existingData.getReactivePowertoDouble());
                                double newPower = newData.getReactivePowerOnetoDouble();
                                double reactive_power = existingPower + newPower;
                                existingData.setReactivePower(String.valueOf(reactive_power));
                                existingData.setReactivePowerOne(newData.getReactivePowerOne());

                            }
                            if (newData.getLimitPower() != null) {
                                existingData.setLimitPower(newData.getLimitPower());
                            }
                            if (newData.getRelimitPower() != null) {
                                existingData.setRelimitPower(newData.getRelimitPower());
                            }
                            if (newData.getAvcDy() != null) {
                                existingData.setAvcDy(newData.getAvcDy());
                            }
                            return existingData;
                        }
                ));
        powcalSitepowService.saveBatch(new ArrayList<>(PowcalSitepowTempMap.values()));
    }

    public void savePowcalFjpow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalFjpowEntity> PowcalFjpowTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、风机编号、监测时间作为组合键
                            return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getFan_code() + ":" + monitorRecordDoc.getCreateTime();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalFjpowEntity powcalFjpowEntity = new PowcalFjpowEntity();
                            powcalFjpowEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalFjpowEntity.setFannumber(monitorRecordDoc.getFan_number());
                            powcalFjpowEntity.setFanCode(monitorRecordDoc.getFan_code());
                            powcalFjpowEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                            powcalFjpowEntity.setTemplateMachineFlag(monitorRecordDoc.getIs_model());
                            if ("ACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setActivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("REACTIVE".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setReactivePower(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setWinddirection(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setWindSpeed(monitorRecordDoc.getMonitoringValue());
                            } else if ("STATUS".equals(monitorRecordDoc.getPointType())) {
                                powcalFjpowEntity.setStatus(monitorRecordDoc.getMonitoringValue());
                            }
                            return powcalFjpowEntity;
                        },
                        // 合并函数，当两个对象具有相同的组合键时调用
                        (existingData, newData) -> {
                            if (newData.getTemplateMachineFlag() != null) {
                                existingData.setTemplateMachineFlag(newData.getTemplateMachineFlag());
                            }
                            if (newData.getActivePower() != null) {
                                existingData.setActivePower(newData.getActivePower());
                            }
                            if (newData.getReactivePower() != null) {
                                existingData.setReactivePower(newData.getReactivePower());
                            }
                            if (newData.getWinddirection() != null) {
                                existingData.setWinddirection(newData.getWinddirection());
                            }
                            if (newData.getWindSpeed() != null) {
                                existingData.setWindSpeed(newData.getWindSpeed());
                            }
                            if (newData.getStatus() != null) {
                                existingData.setStatus(newData.getStatus());
                            }
                            return existingData;
                        }
                ));
        powcalFjpowService.saveBatch(new ArrayList<>(PowcalFjpowTempMap.values()));
    }

    public void savePowcalCftwind(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalCftwindEntity> powcalCftwindTempMap = pendingList.stream()
                .collect(Collectors.toMap(
                        monitorRecordDoc -> {
                            // 使用场站、位置、监测时间和设备类型作为组合键
                            return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getFJ_HEIGHT() + ":" + monitorRecordDoc.getCreateTime() + ":" + monitorRecordDoc.getDeviceType();
                        },
                        monitorRecordDoc -> {
                            // 创建一个新的Map来存储合并后的数据
                            PowcalCftwindEntity powcalCftwindEntity = new PowcalCftwindEntity();
                            powcalCftwindEntity.setSiteId(monitorRecordDoc.getSiteid());
                            powcalCftwindEntity.setLocation(monitorRecordDoc.getDeviceType());
                            powcalCftwindEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                            powcalCftwindEntity.setLocation(monitorRecordDoc.getFJ_HEIGHT());
                            String pointType = monitorRecordDoc.getPointType();
                            if ("SPEED_H".equals(pointType) || "SPEED".equals(pointType)) {
                                powcalCftwindEntity.setWs(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION_H".equals(pointType) || "DIRECTION".equals(pointType)) {
                                powcalCftwindEntity.setWdir(monitorRecordDoc.getMonitoringValue());
                            } else if ("DIRECTION_AVG".equals(pointType)) {
                                powcalCftwindEntity.setSpWdir(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED_AVG".equals(pointType)) {
                                powcalCftwindEntity.setSpWs(monitorRecordDoc.getMonitoringValue());
                            } else if ("SPEED_SDH".equals(pointType)) {
                                powcalCftwindEntity.setPzc(monitorRecordDoc.getMonitoringValue());
                            }

                            return powcalCftwindEntity;
                        },
                        // 合并函数，当两个对象具有相同的组合键时调用
                        (existingData, newData) -> {
                            if (newData.getWs() != null) {
                                existingData.setWs(newData.getWs());
                            }
                            if (newData.getWdir() != null) {
                                existingData.setWdir(newData.getWdir());
                            }
                            if (newData.getPzc() != null) {
                                existingData.setPzc(newData.getPzc());
                            }
                            if (newData.getSpWdir() != null) {
                                existingData.setSpWdir(newData.getSpWdir());
                            }
                            if (newData.getSpWs() != null) {
                                existingData.setSpWs(newData.getSpWs());
                            }
                            return existingData;
                        }
                ));
        powcalCftwindService.saveBatch(new ArrayList<>(powcalCftwindTempMap.values()));
    }

    public void savePowcalSitetherpow(List<J60870MonitorRecordEntity> pendingList) {
        Map<String, PowcalSitetherEntity> powcalSitetherTempMap = pendingList.stream().collect(Collectors.toMap(
                monitorRecordDoc -> {
                    // 使用场站、监测时间作为组合键
                    return monitorRecordDoc.getSiteid() + ":" + monitorRecordDoc.getCreateTime();
                },
                monitorRecordDoc -> {
                    // 创建一个新的Map来存储合并后的数据
                    PowcalSitetherEntity powcalSitetherEntity = new PowcalSitetherEntity();
                    powcalSitetherEntity.setSiteId(monitorRecordDoc.getSiteid());
                    powcalSitetherEntity.setHappen_time(monitorRecordDoc.getCreateTime());
                    if ("TEMPERATURE".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_t(monitorRecordDoc.getMonitoringValue());
                    } else if ("HUMIDITY".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_h(monitorRecordDoc.getMonitoringValue());
                    } else if ("PRESSURE".equals(monitorRecordDoc.getPointType())) {
                        powcalSitetherEntity.setWt_p(monitorRecordDoc.getMonitoringValue());
                    }
                    return powcalSitetherEntity;
                },
                // 合并函数，当两个对象具有相同的组合键时调用
                (existingData, newData) -> {
                    if (newData.getWt_p() != null) {
                        existingData.setWt_p(newData.getWt_p());
                    }
                    if (newData.getWt_h() != null) {
                        existingData.setWt_h(newData.getWt_h());
                    }
                    if (newData.getWt_t() != null) {
                        existingData.setWt_t(newData.getWt_t());
                    }
                    return existingData;
                }
        ));
        powcalSitetherService.saveBatch(new ArrayList<>(powcalSitetherTempMap.values()));
    }

    private Double booleanHandle(Double b) {
        return b > 0.0 ? 0.0 : Math.abs(b);
    }

    public void  dataPlus_manyDay(LocalDate startDay, LocalDate endDay) throws Exception {
        while (startDay.isBefore(endDay) || startDay.equals(endDay)) {
            LocalDateTime startTime = startDay.atTime(0, 0, 0);
            LocalDateTime endTime = startDay.atTime(23, 59, 59);

            val sitepowWrapper=new LambdaQueryWrapper<PowcalSitepowEntity>();
            sitepowWrapper.between(PowcalSitepowEntity::getHappenTime, startTime, endTime);
            powcalSitepowMapper.delete(sitepowWrapper);

            val fjpowWrapper=new LambdaQueryWrapper<PowcalFjpowEntity>();
            fjpowWrapper.between(PowcalFjpowEntity::getHappen_time, startTime, endTime);
            powcalFjpowMapper.delete(fjpowWrapper);;

            val cftwindWrapper=new LambdaQueryWrapper<PowcalCftwindEntity>();
            cftwindWrapper.between(PowcalCftwindEntity::getHappen_time, startTime, endTime);
            powcalCftwindMapper.delete(cftwindWrapper);;

            val sitetherWrapper=new LambdaQueryWrapper<PowcalSitetherEntity>();
            sitetherWrapper.between(PowcalSitetherEntity::getHappen_time, startTime, endTime);
            powcalSitetherMapper.delete(sitetherWrapper);;

            dataPlus_GD(startTime, endTime);
            startDay = startDay.plusDays(1);
        }
    }

}
