package com.powcal.service.base;

public interface IBaseService {

}
