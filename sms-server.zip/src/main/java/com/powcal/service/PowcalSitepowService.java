package com.powcal.service;

import com.powcal.entity.PowcalSitepowEntity;
import com.powcal.entity.base.AbstractEntityService;
import com.powcal.mapper.PowcalSitepowMapper;
import org.springframework.stereotype.Service;

@Service
public class PowcalSitepowService extends AbstractEntityService<PowcalSitepowMapper, PowcalSitepowEntity> {
}
