package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @des:测风塔风速表
 */
@Data
@NoArgsConstructor
@KeySequence(value = "POWCAL_CFTWINDIDSEQ",dbType=DbType.DM)
@EqualsAndHashCode(callSuper = false)
@TableName(value = "POWCAL_CFTWIND")
public class PowcalCftwindEntity extends AbstractEntity {

    @TableId(value = "POWCAL_CFTWINDID", type = IdType.INPUT)
    private Integer POWCAL_CFTWINDID;

    @TableField(value = "SITEID")
    private String siteId;//场站

    @TableField(value = "SITE_CODE")
    private String site_code;//场站编号

    @TableField(value = "HAPPEN_TIME")
    private LocalDateTime happen_time;//监测时间

    @TableField(value = "LOCATION")
    private String location;//位置

    @TableField(value = "WDIR")
    private String wdir;//风向

    @TableField(value = "WS")
    private String ws;//风速

    @TableField(value = "SP_WDIR")
    private String spWdir;//水平平均风向

    @TableField(value = "SP_WS")
    private String spWs;//水平平均风速

    @TableField(value = "PZC")
    private String pzc;//标准差

    @TableField(value = "HASLD")
    private Integer hasld=0;

    @Override
    public Serializable getId() {
        return this.POWCAL_CFTWINDID;
    }
}
