package com.powcal.entity.base;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.convert.Convert;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.TableInfo;
import com.baomidou.mybatisplus.core.metadata.TableInfoHelper;
import com.baomidou.mybatisplus.core.toolkit.Assert;
import com.baomidou.mybatisplus.core.toolkit.ReflectionKit;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.powcal.mapper.base.IPlusMapper;
import com.powcal.service.base.IBaseService;
import com.powcal.utils.IdUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.*;

public abstract class AbstractEntityService<M extends IPlusMapper<T>, T extends IPlusEntity> extends ServiceImpl<M, T> implements IBaseService {
    protected Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean saveOrUpdate(T entity) {
        if (entity != null) {
            TableInfo tableInfo = TableInfoHelper.getTableInfo(this.entityClass);
            Assert.notNull(tableInfo, "error: can not execute. because can not find cache of TableInfo for entity!");
            String keyProperty = tableInfo.getKeyProperty();
            Assert.notEmpty(keyProperty, "error: can not execute. because can not find column for id from entity!");
            Object idVal = ReflectionKit.getFieldValue(entity, tableInfo.getKeyProperty());
            if (tableInfo.getIdType() == IdType.AUTO) {//如果为自增  有id则更新 无id则插入  无需检查数据是否存在
                return StringUtils.checkValNull(idVal) ? save(entity) : updateById(entity);
            }
            return !StringUtils.checkValNull(idVal) && Objects.isNull(getById((Serializable) idVal)) ? save(entity) : updateById(entity);
        }
        return false;
    }

    public T findById(Serializable id) {
        if (IdUtils.isValidId(id)) {
            return getById(id);
        }
        return null;
    }

    public List<T> findByIds(Collection<? extends Serializable> ids) {
        return findByIds(ids, false);
    }

    public List<T> findByIds(Collection<? extends Serializable> ids, boolean unique) {
        if (CollUtil.isNotEmpty(ids)) {
            Collection<Serializable> idColl;
            if (unique) {
                idColl = new LinkedHashSet<>();
            } else {
                idColl = new ArrayList<>();
            }
            for (Serializable id : ids) {
                if (IdUtils.isValidId(id)) {
                    idColl.add(id);
                }
            }
            if (CollUtil.size(idColl) > 1000) {
                List<T> resultList = new ArrayList<>();
                for (List<Serializable> subIdColl : CollUtil.split(idColl, 1000)) {
                    List<T> subList = listByIds(subIdColl);
                    if (CollUtil.isNotEmpty(subList)) {
                        resultList.addAll(subList);
                    }
                }
                return resultList;
            } else if (CollUtil.isNotEmpty(idColl)) {
                return listByIds(idColl);
            }
        }
        return new ArrayList<>();
    }

    public T get(Serializable id) {
        return findById(id);
    }

    public <K extends Serializable> Map<String, T> multiGetMap(Collection<K> idList) {
        List<T> list = findByIds(idList);
        if (CollUtil.isNotEmpty(list)) {
            Map<String, T> entityMap = new LinkedHashMap<>();
            for (T entity : list) {
                entityMap.put(entity.getId().toString(), entity);
            }
            return entityMap;
        }
        return new HashMap<>();
    }
}
