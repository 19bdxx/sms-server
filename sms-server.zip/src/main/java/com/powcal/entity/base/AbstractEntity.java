package com.powcal.entity.base;

import com.baomidou.mybatisplus.annotation.TableField;
import com.powcal.common.state.State;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serial;

@NoArgsConstructor
@EqualsAndHashCode
public abstract class AbstractEntity implements IPlusEntity {
    @Serial
    private static final long serialVersionUID = 1L;


}
