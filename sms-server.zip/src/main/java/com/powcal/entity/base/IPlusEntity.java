package com.powcal.entity.base;

import java.io.Serializable;

public interface IPlusEntity extends Serializable {

    Serializable getId();

}