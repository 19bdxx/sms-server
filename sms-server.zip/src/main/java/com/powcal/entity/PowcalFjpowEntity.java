package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @des:风机功率监测数据表
 */
@Data
@NoArgsConstructor
@KeySequence(value = "POWCAL_FJPOWIDSEQ",dbType=DbType.DM)
@EqualsAndHashCode(callSuper = false)
@TableName(value = "POWCAL_FJPOW")
public class PowcalFjpowEntity extends AbstractEntity {

    @TableId(value = "POWCAL_FJPOWID", type = IdType.INPUT)
    private Integer POWCAL_FJPOWID;

    @TableField(value = "SITEID")
    private String siteId;//场站

    @TableField(value = "SITE_CODE")
    private String site_code;//场站编号

    @TableField(value = "FANNUMBER")
    private String fannumber;//风机名称

    @TableField(value = "FANCODE")
    private String fanCode;//风机编号

    @TableField(value = "HAPPEN_TIME")
    private LocalDateTime happen_time;//监测时间

    @TableField(value = "WINDDIRECTION")
    private String winddirection;//风向

    @TableField(value = "WINDSPEED")
    private String windSpeed;//风速

    @TableField(value = "ACTIVE_POWER")
    private String activePower;//有功

    @TableField(value = "REACTIVE_POWER")
    private String reactivePower;//无功

    @TableField(value = "STATUS")
    private String status;//状态

    @TableField(value = "TEMPLATEMACHINEFLAG")
    private String templateMachineFlag;//是否是样板机

    @TableField(value = "HASLD")
    private Integer hasld=0;

    @Override
    public Serializable getId() {
        return this.POWCAL_FJPOWID;
    }
}
