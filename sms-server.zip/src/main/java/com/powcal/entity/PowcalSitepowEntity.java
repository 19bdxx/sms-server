package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.powcal.common.state.SiteStateFactory;
import com.powcal.common.state.State;
import com.powcal.common.state.gd.GdyjxyaState;
import com.powcal.entity.base.AbstractEntity;
import com.powcal.utils.ConvertUtils;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @des:场站功率监测数据表
 */
@NoArgsConstructor
@Getter
@Setter
@KeySequence(value = "POWCAL_SITEIDSEQ",dbType=DbType.DM)
@EqualsAndHashCode(callSuper = false)
@TableName(value = "POWCAL_SITEPOW")
public class PowcalSitepowEntity extends AbstractEntity {

    @TableId(value = "POWCAL_SITEID", type = IdType.INPUT)
    private Integer powcalSiteId;//主表ID

    @TableField(value = "SITEID")
    private String siteId;//场站id

    @TableField(value = "SITE_CODE")
    private String siteCode;//场站编号

    @TableField(value = "HAPPEN_TIME")
    private LocalDateTime happenTime;//监测时间(分钟级)

    @TableField(value = "ACTIVE_POWER")
    private String activePower;//有功

    @TableField(value = "REACTIVE_POWER")
    private String reactivePower;//无功

    @TableField(value = "LIMIT_POWER")
    private String limitPower;//限电\AVC有功指令

    @TableField(value = "RELIMIT_POWER")
    private String relimitPower;//AVC无功指令

    @TableField(value = "AVC_DY")
    private String avcDy;//AVC电压指令

    @TableField(value = "QCKJRL")
    private String qckjrl;//全厂开机容量

    @TableField(value = "ACTIVE_POWER_ONE")
    private String activePowerOne;//有功功率一次值

    @TableField(value = "REACTIVE_POWER_ONE")
    private String reactivePowerOne;//无功功率一次值

    @TableField(value = "HASLD")
    private Integer hasld=0;

    private transient State state;
    @Override
    public Serializable getId() {
        return this.powcalSiteId;
    }

    public Double getActivePowertoDouble(){
        return getState().hendler(ConvertUtils.toDouble(this.activePower,0.0));
    }
    public Double getReactivePowertoDouble(){
        return ConvertUtils.toDouble(this.reactivePower,0.0);
    }

    public Double getReactivePowerOnetoDouble(){
        return ConvertUtils.toDouble(this.limitPower,0.0);
    }
    public Double getActivePowerOnetoDouble(){
        return getState().hendler(ConvertUtils.toDouble(this.activePowerOne, 0.0));
    }
    public Double getLimitPowertoDouble(){
        return getState().hendler(ConvertUtils.toDouble(this.reactivePowerOne, 0.0));
    }


    public String getReactivePowerOne() {
        return reactivePowerOne;
    }

    public void setSiteId(String siteId) {
        setState(SiteStateFactory.getState(siteId));
        this.siteId = siteId;
    }


    private void setState(State state) {
        this.state = state;
    }
    private State getState() {
        return state;
    }
}
