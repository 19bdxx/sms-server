package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @des:场站温度表
 */
@Data
@NoArgsConstructor
@KeySequence(value = "POWCAL_SITETHERIDSEQ",dbType=DbType.DM)
@EqualsAndHashCode(callSuper = false)
@TableName(value = "POWCAL_SITETHER")
public class PowcalSitetherEntity extends AbstractEntity {

    @TableId(value = "POWCAL_SITETHERID", type = IdType.INPUT)
    private Integer POWCAL_SITETHERID;//主表ID

    @TableField(value = "SITEID")
    private String siteId;//场站id

    @TableField(value = "SITE_CODE")
    private String site_code;//场站编号

    @TableField(value = "HAPPEN_TIME")
    private LocalDateTime happen_time;//监测时间(分钟级)

    @TableField(value = "WT_T")
    private String wt_t;//温度

    @TableField(value = "WT_H")
    private String wt_h;//湿度

    @TableField(value = "WT_P")
    private String wt_p;//气压

    @TableField(value = "HASLD")
    private Integer hasld=0;

    @Override
    public Serializable getId() {
        return this.POWCAL_SITETHERID;
    }
}
