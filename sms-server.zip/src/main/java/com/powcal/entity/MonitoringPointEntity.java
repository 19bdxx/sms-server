package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serial;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@TableName(value = "MONITORING_POINT")
public class MonitoringPointEntity extends AbstractEntity {
    @Serial
    private static final long serialVersionUID = 1L;

    @TableId(value = "MONITORING_POINTID", type = IdType.INPUT)
    private Integer id;//ID

    @TableField(value = "SITES")
    private String sites;//站点

    @TableField(value = "DEVICE_TYPE")
    private String deviceType;//设备类型

    @TableField(value = "POINT_TYPE")
    private String pointType;//测点类型

    @TableField(value = "MONITORING_POINT")
    private String monitoringPoint;//测点

    @TableField(value = "STATUS")
    private String status;//状态

}
