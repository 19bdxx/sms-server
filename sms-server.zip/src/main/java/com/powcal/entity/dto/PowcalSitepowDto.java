package com.powcal.entity.dto;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.KeySequence;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @des:场站功率监测数据表
 */
@Data
@KeySequence(value = "POWCAL_SITEIDSEQ",dbType=DbType.DM)
@EqualsAndHashCode(callSuper = false)
@TableName(value = "POWCAL_SITEPOW")
public class PowcalSitepowDto extends AbstractEntity {

    private Integer POWCALSITEID;//主表ID

    @TableField(value = "SITEID")
    private String siteId;//场站id

    @TableField(value = "SITE_CODE")
    private String siteCode;//场站编号

    @TableField(value = "HAPPEN_TIME")
    private LocalDateTime happenTime;//监测时间(分钟级)

    @TableField(value = "ACTIVE_POWER")
    private String activePower;//有功

    @TableField(value = "REACTIVE_POWER")
    private String reactivePower;//无功

    @TableField(value = "LIMIT_POWER")
    private String limitPower;//限电\AVC有功指令

    @TableField(value = "RELIMIT_POWER")
    private String relimitPower;//AVC无功指令

    @TableField(value = "AVC_DY")
    private String avcDy;//AVC电压指令

    @TableField(value = "ACTIVE_POWER_ONE")
    private String activePowerOne;//有功功率一次值

    @TableField(value = "REACTIVE_POWER_ONE")
    private String reactivePowerOne;//无功功率一次值


    @TableField(value = "HASLD")
    private Integer hasld=0;

    @Override
    public Serializable getId() {
        return this.POWCALSITEID;
    }


}
