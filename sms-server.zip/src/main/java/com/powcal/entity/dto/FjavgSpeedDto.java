package com.powcal.entity.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author 孙泽鑫韬
 * @packageName:com.dataProcessing.entity.dto
 * @class:fjavgSpeedDto
 * @date2024/3/8 10:08
 */

@Data
public class FjavgSpeedDto {
    private LocalDateTime time;
    private Double avgSpeed;
}
