package com.powcal.entity.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serial;
import java.io.Serializable;

/**
 * 该类是为了接收某站点中测点信息
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SiteMonitoringPointsDto extends AbstractEntity {
    @Serial
    private static final long serialVersionUID = 1L;

    @TableField(value = "SITES")
    private String sites;//站点
    @TableField(value = "MONITORING_POINT")
    private String monitoringPoint;//测点

    @TableField(value = "POWER_DISPATCH_ORG")
    private String powerDispatchOrg;//站点名

    @Override
    public Serializable getId() {
        return null;
    }
}
