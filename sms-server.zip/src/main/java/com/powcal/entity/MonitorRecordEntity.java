package com.powcal.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.powcal.entity.base.AbstractEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @Author 喻俊杰
 * @Date:2024/3/7
 * @Description: 历史实际功率表
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@TableName(value = "MONITOR_RECORD")
public class MonitorRecordEntity extends AbstractEntity {

    @TableId(value = "ID", type = IdType.INPUT)
    private String id;

    @TableField(value = "CREATETIME")
    private LocalDateTime createTime;//数据时间

    @TableField(value = "SITES")
    private String sites;//站点

    @TableField(value = "DEVICETYPE")
    private String deviceType;//设备类型

    @TableField(value = "POINTTYPE")
    private String pointType;//点号类型

    @TableField(value = "MONITORINGPOINT")
    private String monitoringPoint;//点号

    @TableField(value = "MONITORINGVALUE")
    private String monitoringValue;//点号值

    @TableField(value = "BF_FLAG")
    private String bfFlag;//是否备份 默认值0

    @TableField(value = "FAN_CODE")
    private String fan_code;//风机编号

    @TableField(value = "IS_MODEL")
    private String is_model;//是否是样板机

    @TableField(value = "FJ_HEIGHT")
    private String fj_height;//测点对应位置高度



}
